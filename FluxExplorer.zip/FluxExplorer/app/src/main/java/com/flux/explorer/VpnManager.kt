package com.flux.explorer

import android.content.Context
import androidx.core.content.ContextCompat
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature

/**
 * Flux VPN: routes every request made by Flux Explorer's WebViews through a proxy server,
 * so websites see the server's IP instead of yours. This is the same idea as the
 * "browser VPN" in Opera: it protects this browser only, not other apps on the phone.
 *
 * There is deliberately NO direct fallback: if the proxy is down, pages fail to load
 * instead of silently leaking your real IP.
 */
object VpnManager {

    fun supported(): Boolean =
        WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)

    fun connect(ctx: Context, server: VpnServer, done: (Boolean) -> Unit) {
        if (!supported()) {
            done(false)
            return
        }
        try {
            val cfg = ProxyConfig.Builder()
                .addProxyRule("${server.scheme}://${server.host}:${server.port}")
                .build()
            ProxyController.getInstance()
                .setProxyOverride(cfg, ContextCompat.getMainExecutor(ctx), Runnable { done(true) })
        } catch (e: Exception) {
            done(false)
        }
    }

    fun disconnect(ctx: Context, done: () -> Unit) {
        try {
            if (supported()) {
                ProxyController.getInstance()
                    .clearProxyOverride(ContextCompat.getMainExecutor(ctx), Runnable { done() })
                return
            }
        } catch (_: Exception) {
        }
        done()
    }
}
