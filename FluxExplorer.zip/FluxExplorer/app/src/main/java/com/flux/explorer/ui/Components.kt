package com.flux.explorer.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.TravelExplore
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class MainTab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Outlined.Home),
    Explore("Explore", Icons.Outlined.TravelExplore),
    Vpn("VPN", Icons.Outlined.Shield),
    Settings("Settings", Icons.Outlined.Settings)
}

@Composable
fun navyBrush(): Brush = Brush.linearGradient(listOf(P.navy, P.navy2))

/** Floating pill bottom bar: the selected tab expands into a navy pill with its label. */
@Composable
fun FxBottomBar(selected: MainTab, onSelect: (MainTab) -> Unit, modifier: Modifier = Modifier) {
    val p = P
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .shadow(10.dp, RoundedCornerShape(30.dp))
            .clip(RoundedCornerShape(30.dp))
            .background(p.card)
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        MainTab.values().forEach { t ->
            val sel = t == selected
            Row(
                Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .background(if (sel) p.navy else Color.Transparent)
                    .clickable { onSelect(t) }
                    .padding(horizontal = if (sel) 18.dp else 14.dp, vertical = 12.dp)
                    .animateContentSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    t.icon, t.label,
                    tint = if (sel) Color.White else p.muted,
                    modifier = Modifier.size(22.dp)
                )
                if (sel) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        t.label, color = Color.White, fontSize = 14.sp,
                        fontWeight = FontWeight.Medium, maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun FxCard(
    modifier: Modifier = Modifier,
    color: Color = P.card,
    radius: Dp = 24.dp,
    content: @Composable () -> Unit
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(radius))
            .background(color)
    ) { content() }
}

@Composable
fun CircleIcon(
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    bg: Color = P.card,
    tint: Color = P.text
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(bg)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

/** White circle with an arrow, like the arrow buttons in the reference design. */
@Composable
fun ArrowButton(modifier: Modifier = Modifier, size: Dp = 40.dp) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Filled.ArrowForward, null, tint = Color(0xFF0B1F3F), modifier = Modifier.size(size * 0.45f))
    }
}

/** Navy circle with a white arrow, for use on light cards. */
@Composable
fun ArrowButtonDark(modifier: Modifier = Modifier, size: Dp = 36.dp) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(P.navy),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Filled.ArrowForward, null, tint = Color.White, modifier = Modifier.size(size * 0.45f))
    }
}

@Composable
fun SearchPill(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    onGo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val p = P
    Row(
        modifier
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(p.card)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Outlined.Search, null, tint = p.muted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(placeholder, color = p.muted, fontSize = 14.sp, maxLines = 1)
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = TextStyle(color = p.text, fontSize = 15.sp),
                cursorBrush = SolidColor(p.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                keyboardActions = KeyboardActions(onGo = { onGo() }),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text, color = P.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
        modifier = modifier
    )
}

@Composable
fun StatusChip(label: String, on: Boolean) {
    Row(
        Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (on) P.good else Color(0xFF8C9BB3))
        )
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
fun ColumnStat(value: String, label: String, icon: ImageVector, modifier: Modifier = Modifier) {
    val p = P
    Column(modifier, horizontalAlignment = Alignment.Start) {
        Text(label, color = p.muted, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(value, color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            Icon(icon, null, tint = p.accent, modifier = Modifier.size(16.dp))
        }
    }
}
