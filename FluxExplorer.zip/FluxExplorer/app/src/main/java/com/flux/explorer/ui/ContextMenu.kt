package com.flux.explorer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flux.explorer.BrowserViewModel

/** Long-press menu for images and links, like Chrome's. */
@Composable
fun ContextMenuSheet(vm: BrowserViewModel) {
    val t = vm.contextMenu ?: return
    val p = P
    val image = t.image
    val link = t.link
    val incognito = vm.current?.incognito == true

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { vm.contextMenu = null }
    ) {
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(12.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(26.dp))
                .background(p.baseBg)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { }
                .padding(vertical = 10.dp)
        ) {
            Text(
                image ?: link ?: "",
                color = p.muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
            )

            if (image != null) {
                MenuRow(Icons.Outlined.Download, "Download image") { vm.downloadImage(image) }
                MenuRow(Icons.Outlined.ContentCopy, "Copy image link") { vm.copyText(image, "Image link copied") }
                MenuRow(Icons.Outlined.OpenInNew, "Open image in new tab") { vm.openInBackgroundTab(image, incognito) }
                MenuRow(Icons.Outlined.Share, "Share image link") { vm.shareText(image) }
            }
            if (link != null) {
                MenuRow(Icons.Outlined.OpenInNew, "Open link in new tab") { vm.openInBackgroundTab(link, incognito) }
                if (!incognito) {
                    MenuRow(Icons.Outlined.VisibilityOff, "Open link in private tab") { vm.openInBackgroundTab(link, true) }
                }
                MenuRow(Icons.Outlined.ContentCopy, "Copy link address") { vm.copyText(link, "Link copied") }
                MenuRow(Icons.Outlined.Download, "Download link") { vm.downloadLink(link) }
                MenuRow(Icons.Outlined.Share, "Share link") { vm.shareText(link) }
            }
            Spacer(Modifier.height(2.dp))
        }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    val p = P
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(p.sky),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = p.accent, modifier = Modifier.size(19.dp)) }
        Spacer(Modifier.width(14.dp))
        Text(label, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}
