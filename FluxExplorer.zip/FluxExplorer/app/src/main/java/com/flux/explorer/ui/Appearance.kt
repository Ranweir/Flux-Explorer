package com.flux.explorer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flux.explorer.BrowserViewModel

@Composable
fun AppearanceScreen(vm: BrowserViewModel) {
    val p = P
    val a = vm.ap

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 40.dp)
    ) {
        // ---------------- Theme ----------------
        Group("Theme") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                    Choice(label, a.themeMode == i, Modifier.weight(1f)) {
                        vm.updateAp { it.copy(themeMode = i) }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Colour theme", color = p.muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Accents.forEachIndexed { i, set ->
                    val sel = a.accentIdx == i
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(set.navy2L, set.accentL)))
                                .border(if (sel) 3.dp else 0.dp, if (sel) p.text else Color.Transparent, CircleShape)
                                .clickable { vm.updateAp { it.copy(accentIdx = i) } },
                            contentAlignment = Alignment.Center
                        ) {
                            if (sel) Icon(Icons.Outlined.Check, null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(set.name, color = p.muted, fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }

        // ---------------- Wallpaper ----------------
        Group("Wallpaper") {
            // item 0 = none, 1..6 = gradients, 7 = own photo
            val total = WallpaperGradients.size + 2
            (0 until total).chunked(4).forEach { rowItems ->
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowItems.forEach { idx ->
                        val isNone = idx == 0
                        val isPhoto = idx == total - 1
                        val gradIdx = idx - 1
                        val selected = when {
                            isNone -> a.wallpaperKind == 0
                            isPhoto -> a.wallpaperKind == 2
                            else -> a.wallpaperKind == 1 && a.gradientIdx == gradIdx
                        }
                        val label = when {
                            isNone -> "None"
                            isPhoto -> "Your photo"
                            else -> WallpaperGradients[gradIdx].name
                        }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(0.8f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        when {
                                            isNone || isPhoto -> Brush.linearGradient(listOf(p.sky, p.sky))
                                            else -> Brush.linearGradient(WallpaperGradients[gradIdx].colors)
                                        }
                                    )
                                    .border(
                                        if (selected) 3.dp else 0.dp,
                                        if (selected) p.accent else Color.Transparent,
                                        RoundedCornerShape(14.dp)
                                    )
                                    .clickable {
                                        when {
                                            isNone -> vm.updateAp { it.copy(wallpaperKind = 0) }
                                            isPhoto -> {
                                                if (vm.wallpaper != null && a.wallpaperKind != 2) {
                                                    vm.updateAp { it.copy(wallpaperKind = 2) }
                                                } else {
                                                    vm.launchWallpaperPicker?.invoke()
                                                }
                                            }
                                            else -> vm.updateAp { it.copy(wallpaperKind = 1, gradientIdx = gradIdx) }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                val bmp = vm.wallpaper
                                when {
                                    isNone -> Icon(Icons.Outlined.Block, null, tint = p.muted, modifier = Modifier.size(22.dp))
                                    isPhoto && bmp != null -> Image(
                                        bitmap = bmp, contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    isPhoto -> Icon(Icons.Outlined.AddPhotoAlternate, null, tint = p.accent, modifier = Modifier.size(26.dp))
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(label, color = p.muted, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                    // keep the last row's tiles the same width as the others
                    repeat(4 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            if (vm.wallpaper != null && a.wallpaperKind == 2) {
                Text(
                    "Tap \"Your photo\" again to choose a different picture.",
                    color = p.muted, fontSize = 11.sp
                )
            }
            if (a.wallpaperKind != 0) {
                Spacer(Modifier.height(12.dp))
                SliderRow("Dim", "${(a.wpDim * 100).toInt()}%", a.wpDim, 0f..0.7f) { v ->
                    vm.updateAp { it.copy(wpDim = v) }
                }
            }
            if (a.wallpaperKind == 2) {
                SliderRow("Blur (Android 12+)", "${a.wpBlur.toInt()}", a.wpBlur, 0f..25f) { v ->
                    vm.updateAp { it.copy(wpBlur = v) }
                }
            }
        }

        // ---------------- Liquid glass ----------------
        Group("Liquid glass") {
            SliderRow("Glass opacity", "${(a.glass * 100).toInt()}%", a.glass, 0.35f..1f) { v ->
                vm.updateAp { it.copy(glass = v) }
            }
            SliderRow("Glass blur (photo wallpaper)", "${a.glassBlur.toInt()}", a.glassBlur, 0f..25f) { v ->
                vm.updateAp { it.copy(glassBlur = v) }
            }
            SliderRow("Corner roundness", "${a.radius} dp", a.radius.toFloat(), 12f..36f) { v ->
                vm.updateAp { it.copy(radius = v.toInt()) }
            }
            PrefSwitch("Glass edge shine", "Soft highlight on card borders", a.shine) { v ->
                vm.updateAp { it.copy(shine = v) }
            }
            PrefSwitch("Animations", "Bottom bar and VPN pulse", a.animations) { v ->
                vm.updateAp { it.copy(animations = v) }
            }
        }

        // ---------------- Status & navigation bar ----------------
        Group("Status & navigation bar") {
            PrefSwitch("Frosted status bar", "Glass strip behind the clock and battery", a.sbGlass) { v ->
                vm.updateAp { it.copy(sbGlass = v) }
            }
            PrefSwitch("Frosted navigation bar", "Glass strip behind the gesture line", a.nbGlass) { v ->
                vm.updateAp { it.copy(nbGlass = v) }
            }
            if (a.sbGlass || a.nbGlass) {
                SliderRow("Bar tint strength", "${(a.sbOpacity * 100).toInt()}%", a.sbOpacity, 0f..1f) { v ->
                    vm.updateAp { it.copy(sbOpacity = v) }
                }
                Text("Bar tint", color = p.muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Auto", "Light", "Dark", "Accent").forEachIndexed { i, label ->
                        Choice(label, a.sbTint == i, Modifier.weight(1f)) {
                            vm.updateAp { it.copy(sbTint = i) }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
            Text("Status bar icons", color = p.muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Auto", "White", "Black").forEachIndexed { i, label ->
                    Choice(label, a.sbIcons == i, Modifier.weight(1f)) {
                        vm.updateAp { it.copy(sbIcons = i) }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "The strip blurs your photo wallpaper behind it; the Glass blur slider above sets the strength.",
                color = p.muted, fontSize = 11.sp
            )
        }

        // ---------------- Home screen ----------------
        Group("Home screen") {
            PrefSwitch("Top island", "Live VPN and blocked-count pill", a.showIsland) { v ->
                vm.updateAp { it.copy(showIsland = v) }
            }
            PrefSwitch("Greeting", "Good morning, afternoon, evening", a.showGreeting) { v ->
                vm.updateAp { it.copy(showGreeting = v) }
            }
            PrefSwitch("Clock", "Large time display", a.showClock) { v ->
                vm.updateAp { it.copy(showClock = v) }
            }
            if (a.showClock) {
                PrefSwitch("24-hour clock", "Off shows AM / PM", a.clock24) { v ->
                    vm.updateAp { it.copy(clock24 = v) }
                }
                PrefSwitch("Show date", "Weekday and date under the clock", a.showDate) { v ->
                    vm.updateAp { it.copy(showDate = v) }
                }
            }
            PrefSwitch("Shortcuts dock", "Your bookmarks and favourite sites", a.showShortcuts) { v ->
                vm.updateAp { it.copy(showShortcuts = v) }
            }
            PrefSwitch("Privacy overview", "Ads, trackers and VPN summary", a.showPrivacy) { v ->
                vm.updateAp { it.copy(showPrivacy = v) }
            }
            PrefSwitch("Quick notes", "A notepad on the home screen", a.showNotes) { v ->
                vm.updateAp { it.copy(showNotes = v) }
            }
            PrefSwitch("Quick access", "Bookmarks, history, downloads, private", a.showQuick) { v ->
                vm.updateAp { it.copy(showQuick = v) }
            }
        }

        // ---------------- Reset ----------------
        Box(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(p.sky)
                .clickable { vm.resetAppearance() },
            contentAlignment = Alignment.Center
        ) {
            Text("Reset appearance", color = p.accent, fontWeight = FontWeight.Medium, fontSize = 14.sp)
        }
    }
}

@Composable
private fun Group(title: String, content: @Composable ColumnScope.() -> Unit) {
    val p = P
    Text(title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(10.dp))
    FxCard {
        Column(Modifier.padding(16.dp), content = content)
    }
    Spacer(Modifier.height(18.dp))
}

@Composable
private fun Choice(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val p = P
    Box(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (selected) p.navy else p.sky)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) Color.White else p.accent,
            fontSize = 14.sp, fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun SliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    val p = P
    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = p.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(valueText, color = p.muted, fontSize = 12.sp)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = p.accent,
                activeTrackColor = p.accent,
                inactiveTrackColor = p.sky
            )
        )
    }
}

@Composable
private fun PrefSwitch(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = P
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = p.muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = p.accent, checkedThumbColor = Color.White)
        )
    }
}
