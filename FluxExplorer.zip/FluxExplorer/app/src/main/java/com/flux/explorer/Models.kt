package com.flux.explorer

data class Site(val title: String, val url: String)

data class DownloadItem(val name: String, val url: String, val time: Long)

data class VpnServer(
    val id: String,
    val name: String,
    /** "http" or "https" */
    val scheme: String,
    val host: String,
    val port: Int,
    val user: String = "",
    val pass: String = ""
)

enum class VpnState { Off, Connecting, On, Error }

enum class Overlay { None, Tabs, Bookmarks, History, Downloads }
