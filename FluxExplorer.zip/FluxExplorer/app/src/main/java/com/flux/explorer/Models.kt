package com.flux.explorer

data class Site(val title: String, val url: String)

data class DownloadItem(val name: String, val url: String, val time: Long)

data class VpnServer(
    val id: String,
    val name: String,
    /** "http" or "https" */
    val scheme: String,
    val host: String,
    val port: Int,
    val user: String = "",
    val pass: String = ""
)

/** What the user long-pressed in a page: a link, an image, or an image that is also a link. */
data class ContextTarget(val link: String?, val image: String?)

enum class VpnState { Off, Connecting, On, Error }

enum class Overlay { None, Tabs, Bookmarks, History, Downloads, Appearance, Extensions }

/** All look-and-feel options (the Appearance screen). */
data class Appearance(
    val themeMode: Int = 0,          // 0 system, 1 light, 2 dark
    val accentIdx: Int = 0,
    val wallpaperKind: Int = 0,      // 0 none, 1 gradient, 2 own photo
    val gradientIdx: Int = 0,
    val wpBlur: Float = 0f,
    val wpDim: Float = 0.15f,
    val glass: Float = 0.85f,        // card opacity (liquid glass)
    val glassBlur: Float = 12f,      // frosted blur strength behind cards (photo wallpaper)
    val radius: Int = 24,            // corner radius in dp
    val shine: Boolean = true,       // glass edge highlight
    val sbGlass: Boolean = true,     // frosted status bar
    val sbOpacity: Float = 0.35f,    // tint strength of the status / navigation bar glass
    val sbBlur: Float = 20f,         // blur radius of content under the bars (Android 12+)
    val sbTint: Int = 0,             // 0 auto, 1 light, 2 dark, 3 accent
    val sbIcons: Int = 0,            // status bar icons: 0 auto, 1 light, 2 dark
    val nbGlass: Boolean = false,    // frosted navigation bar
    val animations: Boolean = true,
    val showIsland: Boolean = true,
    val showGreeting: Boolean = true,
    val showClock: Boolean = true,
    val clock24: Boolean = false,
    val showDate: Boolean = true,
    val showPrivacy: Boolean = true,
    val showShortcuts: Boolean = true,
    val showNotes: Boolean = true,
    val showQuick: Boolean = true
)
