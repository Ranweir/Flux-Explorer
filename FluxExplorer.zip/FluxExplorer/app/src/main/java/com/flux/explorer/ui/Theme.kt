package com.flux.explorer.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.flux.explorer.Appearance

data class Palette(
    val bg: Color,
    val card: Color,
    val sky: Color,
    val navy: Color,
    val navy2: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val good: Color,
    val bad: Color,
    val dark: Boolean,
    /** Solid background (never see-through), used under wallpapers and on full-screen overlays. */
    val baseBg: Color = Color.Unspecified,
    val radius: Dp = 24.dp,
    val shine: Boolean = true,
    val anim: Boolean = true
)

val LightPalette = Palette(
    bg = Color(0xFFEEF1F6),
    card = Color(0xFFFFFFFF),
    sky = Color(0xFFDCE8FB),
    navy = Color(0xFF0B1F3F),
    navy2 = Color(0xFF1A3C70),
    text = Color(0xFF0F172A),
    muted = Color(0xFF6B7A90),
    accent = Color(0xFF2F6FE4),
    good = Color(0xFF22C55E),
    bad = Color(0xFFE5484D),
    dark = false
)

val DarkPalette = Palette(
    bg = Color(0xFF0A1220),
    card = Color(0xFF121D33),
    sky = Color(0xFF1B2D4F),
    navy = Color(0xFF0F2A56),
    navy2 = Color(0xFF1D4E89),
    text = Color(0xFFE8EEF8),
    muted = Color(0xFF8C9BB3),
    accent = Color(0xFF60A5FA),
    good = Color(0xFF34D399),
    bad = Color(0xFFF87171),
    dark = true
)

/** Colour themes: each has a light and a dark variant. */
data class AccentSet(
    val name: String,
    val navyL: Color, val navy2L: Color, val accentL: Color, val skyL: Color,
    val navyD: Color, val navy2D: Color, val accentD: Color, val skyD: Color
)

val Accents = listOf(
    AccentSet("Ocean", Color(0xFF0B1F3F), Color(0xFF1A3C70), Color(0xFF2F6FE4), Color(0xFFDCE8FB),
        Color(0xFF0F2A56), Color(0xFF1D4E89), Color(0xFF60A5FA), Color(0xFF1B2D4F)),
    AccentSet("Violet", Color(0xFF1E1245), Color(0xFF3B2A7A), Color(0xFF7C5CE8), Color(0xFFE6E0FB),
        Color(0xFF2A1B63), Color(0xFF4C36A0), Color(0xFFA78BFA), Color(0xFF2A2250)),
    AccentSet("Emerald", Color(0xFF0B3326), Color(0xFF14604A), Color(0xFF10A37F), Color(0xFFD5F3E8),
        Color(0xFF0E4030), Color(0xFF1B7A5E), Color(0xFF34D399), Color(0xFF153B31)),
    AccentSet("Sunset", Color(0xFF3F1D0B), Color(0xFF7A3A14), Color(0xFFF26B2A), Color(0xFFFCE4D6),
        Color(0xFF5A2A10), Color(0xFF94491A), Color(0xFFFB923C), Color(0xFF3D2616)),
    AccentSet("Rose", Color(0xFF3F0B24), Color(0xFF7A1A4A), Color(0xFFE23B83), Color(0xFFFBDDEA),
        Color(0xFF5A1236), Color(0xFF94245F), Color(0xFFF472B6), Color(0xFF3D1A2C)),
    AccentSet("Graphite", Color(0xFF111827), Color(0xFF374151), Color(0xFF4B5563), Color(0xFFE5E7EB),
        Color(0xFF1F2937), Color(0xFF4B5563), Color(0xFF9CA3AF), Color(0xFF262C36))
)

data class GradientSpec(val name: String, val colors: List<Color>)

val WallpaperGradients = listOf(
    GradientSpec("Aurora", listOf(Color(0xFF0F2027), Color(0xFF2C5364), Color(0xFF3FA796))),
    GradientSpec("Ocean", listOf(Color(0xFF0B3B8C), Color(0xFF1E88E5), Color(0xFF7CC8FF))),
    GradientSpec("Sunset", listOf(Color(0xFF42275A), Color(0xFFB24592), Color(0xFFF15F79))),
    GradientSpec("Midnight", listOf(Color(0xFF0B1220), Color(0xFF1B2A49), Color(0xFF3B4A7A))),
    GradientSpec("Mint", listOf(Color(0xFF134E4A), Color(0xFF2BB5A0), Color(0xFFB6F0DC))),
    GradientSpec("Violet", listOf(Color(0xFF2B1055), Color(0xFF7597DE), Color(0xFFD5A6F2)))
)

val LocalPalette = staticCompositionLocalOf { LightPalette }

val P: Palette
    @Composable @ReadOnlyComposable get() = LocalPalette.current

@Composable
fun FluxTheme(ap: Appearance, content: @Composable () -> Unit) {
    val dark = when (ap.themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val base = if (dark) DarkPalette else LightPalette
    val set = Accents[ap.accentIdx.coerceIn(0, Accents.lastIndex)]
    val g = ap.glass.coerceIn(0.2f, 1f)
    val p = base.copy(
        bg = base.bg.copy(alpha = g),
        card = base.card.copy(alpha = g),
        sky = (if (dark) set.skyD else set.skyL).copy(alpha = g),
        navy = if (dark) set.navyD else set.navyL,
        navy2 = if (dark) set.navy2D else set.navy2L,
        accent = if (dark) set.accentD else set.accentL,
        baseBg = base.bg,
        radius = ap.radius.coerceIn(8, 40).dp,
        shine = ap.shine,
        anim = ap.animations
    )
    val scheme = if (dark) {
        darkColorScheme(primary = p.accent, background = p.baseBg, surface = p.baseBg)
    } else {
        lightColorScheme(primary = p.accent, background = p.baseBg, surface = p.baseBg)
    }
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
