package com.flux.explorer.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class Palette(
    val bg: Color,
    val card: Color,
    val sky: Color,
    val navy: Color,
    val navy2: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val good: Color,
    val bad: Color,
    val dark: Boolean
)

val LightPalette = Palette(
    bg = Color(0xFFEEF1F6),
    card = Color(0xFFFFFFFF),
    sky = Color(0xFFDCE8FB),
    navy = Color(0xFF0B1F3F),
    navy2 = Color(0xFF1A3C70),
    text = Color(0xFF0F172A),
    muted = Color(0xFF6B7A90),
    accent = Color(0xFF2F6FE4),
    good = Color(0xFF22C55E),
    bad = Color(0xFFE5484D),
    dark = false
)

val DarkPalette = Palette(
    bg = Color(0xFF0A1220),
    card = Color(0xFF121D33),
    sky = Color(0xFF1B2D4F),
    navy = Color(0xFF0F2A56),
    navy2 = Color(0xFF1D4E89),
    text = Color(0xFFE8EEF8),
    muted = Color(0xFF8C9BB3),
    accent = Color(0xFF60A5FA),
    good = Color(0xFF34D399),
    bad = Color(0xFFF87171),
    dark = true
)

val LocalPalette = staticCompositionLocalOf { LightPalette }

val P: Palette
    @Composable @ReadOnlyComposable get() = LocalPalette.current

@Composable
fun FluxTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val p = if (dark) DarkPalette else LightPalette
    val scheme = if (dark) {
        darkColorScheme(primary = p.accent, background = p.bg, surface = p.card)
    } else {
        lightColorScheme(primary = p.navy, background = p.bg, surface = p.card)
    }
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
