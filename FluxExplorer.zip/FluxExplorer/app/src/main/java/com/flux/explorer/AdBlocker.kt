package com.flux.explorer

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Host-based ad and tracker blocker (the same approach most mobile browsers use).
 * A request is blocked when its host, or any parent domain of it, is on a list.
 *
 * classify() returns: 0 = allowed, 1 = ad, 2 = tracker
 */
object AdBlocker {

    private const val EXTRA_FILE = "hosts_extra.txt"
    private const val LIST_URL =
        "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext"

    /** JS that hides common ad containers (cosmetic filtering). */
    const val COSMETIC_JS = """(function(){try{
if(document.getElementById('flux-cosmetic'))return;
var s=document.createElement('style');s.id='flux-cosmetic';
s.textContent='ins.adsbygoogle,.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[aria-label="Advertisement"],iframe[src*="doubleclick.net"],iframe[src*="googlesyndication.com"],iframe[src*="amazon-adsystem.com"],.taboola,.trc_related_container,[id^="taboola-"],[id^="outbrain"],.OUTBRAIN{display:none!important}';
(document.head||document.documentElement).appendChild(s);
}catch(e){}})();"""

    private val ads = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "2mdn.net", "amazon-adsystem.com", "adnxs.com", "adsrvr.org", "advertising.com",
        "adform.net", "rubiconproject.com", "pubmatic.com", "openx.net", "casalemedia.com",
        "criteo.com", "criteo.net", "taboola.com", "outbrain.com", "revcontent.com", "mgid.com",
        "smartadserver.com", "moatads.com", "adcolony.com", "applovin.com", "unityads.unity3d.com",
        "chartboost.com", "inmobi.com", "mopub.com", "vungle.com", "ironsrc.com",
        "supersonicads.com", "popads.net", "popcash.net", "propellerads.com", "exoclick.com",
        "juicyads.com", "trafficjunky.net", "adsterra.com", "bidswitch.net", "contextweb.com",
        "yieldmo.com", "sharethrough.com", "teads.tv", "33across.com", "lijit.com", "sovrn.com",
        "indexww.com", "media.net", "ads.yahoo.com", "ads.linkedin.com", "ads.pinterest.com",
        "adsafeprotected.com", "serving-sys.com", "zedo.com", "tribalfusion.com", "undertone.com",
        "spotxchange.com", "stickyadstv.com", "freewheel.tv", "adition.com", "adtech.de",
        "tapad.com", "adroll.com", "rlcdn.com", "mathtag.com", "turn.com", "yieldlab.net",
        "adkernel.com", "smaato.net", "startapp.com", "admob.com", "ad.gt", "adscale.de",
        "onetag-sys.com", "richaudience.com", "connectad.io", "gumgum.com", "triplelift.com",
        "ads-twitter.com", "ad.doubleclick.net", "cpmstar.com", "adbrite.com", "clickbank.net"
    )

    private val trackers = hashSetOf(
        "google-analytics.com", "analytics.google.com", "googletagservices.com",
        "scorecardresearch.com", "quantserve.com", "quantcount.com", "hotjar.com", "hotjar.io",
        "mixpanel.com", "amplitude.com", "fullstory.com", "mouseflow.com", "crazyegg.com",
        "chartbeat.com", "chartbeat.net", "parsely.com", "comscore.com", "bluekai.com",
        "krxd.net", "demdex.net", "omtrdc.net", "everesttech.net", "2o7.net", "appsflyer.com",
        "app-measurement.com", "analytics.twitter.com", "snap.licdn.com", "px.ads.linkedin.com",
        "bat.bing.com", "clarity.ms", "analytics.tiktok.com", "analytics-sg.tiktok.com",
        "mc.yandex.ru", "counter.yadro.ru", "hm.baidu.com", "cnzz.com", "luckyorange.com",
        "inspectlet.com", "heap.io", "heapanalytics.com", "statcounter.com", "sentry-cdn.com",
        "tags.tiqcdn.com", "branch.io", "kochava.com", "adjust.com", "singular.net",
        "pixel.facebook.com", "an.facebook.com", "track.hubspot.com", "hs-analytics.net",
        "newrelic.com", "nr-data.net", "bugsnag.com", "outbrainimg.com", "addthis.com", "sharethis.com"
    )

    @Volatile
    private var extra: Set<String> = emptySet()

    @Volatile
    var extraCount: Int = 0
        private set

    fun load(ctx: Context) {
        try {
            val f = File(ctx.filesDir, EXTRA_FILE)
            if (f.exists()) {
                val set = HashSet<String>()
                f.forEachLine { set.add(it.trim()) }
                extra = set
                extraCount = set.size
            }
        } catch (_: Exception) {
        }
    }

    fun classify(host: String): Int {
        var h = host.lowercase()
        while (true) {
            if (ads.contains(h) || extra.contains(h)) return 1
            if (trackers.contains(h)) return 2
            val i = h.indexOf('.')
            if (i < 0) return 0
            h = h.substring(i + 1)
        }
    }

    /** Downloads an extra host list and starts using it. Returns the number of hosts, or -1 on failure. */
    suspend fun update(ctx: Context): Int = withContext(Dispatchers.IO) {
        try {
            val conn = URL(LIST_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 25000
            if (conn.responseCode != 200) return@withContext -1
            val set = HashSet<String>()
            conn.inputStream.bufferedReader().useLines { lines ->
                for (raw in lines) {
                    val line = raw.trim()
                    if (line.isEmpty() || line.startsWith("#")) continue
                    val host = line.split(Regex("\\s+")).last().lowercase()
                    if (host.contains('.') && !host.contains('/') && set.size < 60000) set.add(host)
                }
            }
            if (set.isEmpty()) return@withContext -1
            File(ctx.filesDir, EXTRA_FILE).writeText(set.joinToString("\n"))
            extra = set
            extraCount = set.size
            set.size
        } catch (e: Exception) {
            -1
        }
    }
}
