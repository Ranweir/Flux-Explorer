package com.flux.explorer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flux.explorer.BrowserViewModel
import com.flux.explorer.Ext

@Composable
fun ExtensionsScreen(vm: BrowserViewModel) {
    val p = P
    var link by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 40.dp)
    ) {
        FxCard(color = p.sky) {
            Column(Modifier.padding(16.dp)) {
                Text("Chrome extensions on your phone", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Works without desktop mode. Flux runs the page-changing part of an extension (dark mode, " +
                        "ad and cookie-banner removers, YouTube tweaks, site fixes). Extensions that rely on a " +
                        "background page or a toolbar popup only work partly.",
                    color = p.muted, fontSize = 12.sp, lineHeight = 17.sp
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Extension scripts run inside the pages you visit and can read them. Install only extensions you trust. " +
                        "They are switched off in private tabs.",
                    color = p.muted, fontSize = 12.sp, lineHeight = 17.sp
                )
            }
        }

        Spacer(Modifier.height(18.dp))
        SectionTitle("Add an extension")
        Spacer(Modifier.height(10.dp))
        FxCard {
            Column(Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = link,
                    onValueChange = { link = it },
                    label = { Text("Chrome Web Store link or extension ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Install", true, !vm.extBusy && link.isNotBlank(), Modifier.weight(1f)) {
                        vm.installExtensionFromStore(link)
                    }
                    PillButton("From file", false, !vm.extBusy, Modifier.weight(1f)) {
                        vm.launchExtensionPicker?.invoke()
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "From file accepts a .crx or .zip extension package.",
                    color = p.muted, fontSize = 11.sp
                )
            }
        }

        if (vm.extStatus.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(vm.extStatus, color = p.text, fontSize = 13.sp, lineHeight = 18.sp)
        }

        Spacer(Modifier.height(20.dp))
        SectionTitle("Installed (${vm.extensions.size})")
        Spacer(Modifier.height(10.dp))
        if (vm.extensions.isEmpty()) {
            Text("Nothing installed yet.", color = p.muted, fontSize = 13.sp)
        } else {
            vm.extensions.toList().forEach { e -> ExtensionCard(vm, e) }
        }
    }
}

@Composable
private fun ExtensionCard(vm: BrowserViewModel, e: Ext) {
    val p = P
    FxCard(Modifier.padding(bottom = 10.dp), radius = 20.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        e.name, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    if (e.version.isNotBlank()) Text("v${e.version}", color = p.muted, fontSize = 11.sp)
                }
                Switch(
                    checked = e.enabled,
                    onCheckedChange = { vm.setExtensionOn(e.id, it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = p.accent, checkedThumbColor = Color.White)
                )
            }
            if (e.description.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(e.description, color = p.muted, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                val pageScripts = e.scripts.sumOf { it.js.size + it.css.size }
                val note = when {
                    pageScripts == 0 ->
                        "No page scripts: this extension works through a background page or popup, which Flux can't run yet."
                    e.hasBackground || e.hasPopup ->
                        "$pageScripts page script(s) active. Its background or popup part isn't supported, so some features won't work."
                    else -> "$pageScripts page script(s) active."
                }
                Text(
                    note,
                    color = if (pageScripts == 0) p.bad else p.muted,
                    fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Icon(
                    Icons.Outlined.Delete, "Remove", tint = p.muted,
                    modifier = Modifier.size(22.dp).clickable { vm.removeExtension(e.id) }
                )
            }
        }
    }
}

@Composable
private fun PillButton(label: String, primary: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val p = P
    Box(
        modifier
            .height(48.dp)
            .alpha(if (enabled) 1f else 0.45f)
            .clip(RoundedCornerShape(24.dp))
            .background(if (primary) p.navy else p.sky)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (primary) Color.White else p.accent,
            fontSize = 14.sp, fontWeight = FontWeight.Medium
        )
    }
}
