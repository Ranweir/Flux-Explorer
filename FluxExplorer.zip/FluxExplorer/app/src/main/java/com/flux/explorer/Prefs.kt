package com.flux.explorer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("flux_prefs", Context.MODE_PRIVATE)

    private fun bool(key: String, def: Boolean) = sp.getBoolean(key, def)
    private fun putBool(key: String, v: Boolean) {
        sp.edit().putBoolean(key, v).apply()
    }

    var adBlock: Boolean
        get() = bool("adBlock", true)
        set(v) { putBool("adBlock", v) }

    var trackerBlock: Boolean
        get() = bool("trackerBlock", true)
        set(v) { putBool("trackerBlock", v) }

    var cosmetic: Boolean
        get() = bool("cosmetic", true)
        set(v) { putBool("cosmetic", v) }

    var popupBlock: Boolean
        get() = bool("popupBlock", true)
        set(v) { putBool("popupBlock", v) }

    var jsEnabled: Boolean
        get() = bool("js", true)
        set(v) { putBool("js", v) }

    var noThirdPartyCookies: Boolean
        get() = bool("noTpc", true)
        set(v) { putBool("noTpc", v) }

    var vpnOn: Boolean
        get() = bool("vpnOn", false)
        set(v) { putBool("vpnOn", v) }

    var engine: String
        get() = sp.getString("engine", "Google") ?: "Google"
        set(v) { sp.edit().putString("engine", v).apply() }

    var selectedServer: String
        get() = sp.getString("server", "") ?: ""
        set(v) { sp.edit().putString("server", v).apply() }

    var totalAds: Long
        get() = sp.getLong("totalAds", 0L)
        set(v) { sp.edit().putLong("totalAds", v).apply() }

    var totalTrackers: Long
        get() = sp.getLong("totalTrackers", 0L)
        set(v) { sp.edit().putLong("totalTrackers", v).apply() }

    // ---- extensions ----

    var extDisabled: Set<String>
        get() = sp.getStringSet("extDisabled", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("extDisabled", v.toSet()).apply() }

    // ---- appearance ----

    var notes: String
        get() = sp.getString("notes", "") ?: ""
        set(v) { sp.edit().putString("notes", v).apply() }

    fun loadAppearance(): Appearance {
        val d = Appearance()
        return Appearance(
            themeMode = sp.getInt("ap_theme", d.themeMode),
            accentIdx = sp.getInt("ap_accent", d.accentIdx),
            wallpaperKind = sp.getInt("ap_wpKind", d.wallpaperKind),
            gradientIdx = sp.getInt("ap_grad", d.gradientIdx),
            wpBlur = sp.getFloat("ap_blur", d.wpBlur),
            wpDim = sp.getFloat("ap_dim", d.wpDim),
            glass = sp.getFloat("ap_glass", d.glass),
            glassBlur = sp.getFloat("ap_gblur", d.glassBlur),
            radius = sp.getInt("ap_radius", d.radius),
            shine = sp.getBoolean("ap_shine", d.shine),
            sbGlass = sp.getBoolean("ap_sbglass", d.sbGlass),
            sbOpacity = sp.getFloat("ap_sbop2", d.sbOpacity),
            sbBlur = sp.getFloat("ap_sbblur", d.sbBlur),
            sbTint = sp.getInt("ap_sbtint", d.sbTint),
            sbIcons = sp.getInt("ap_sbicons", d.sbIcons),
            nbGlass = sp.getBoolean("ap_nbglass", d.nbGlass),
            animations = sp.getBoolean("ap_anim", d.animations),
            showIsland = sp.getBoolean("ap_island", d.showIsland),
            showGreeting = sp.getBoolean("ap_greeting", d.showGreeting),
            showClock = sp.getBoolean("ap_clock", d.showClock),
            clock24 = sp.getBoolean("ap_clock24", d.clock24),
            showDate = sp.getBoolean("ap_date", d.showDate),
            showPrivacy = sp.getBoolean("ap_privacy", d.showPrivacy),
            showShortcuts = sp.getBoolean("ap_shortcuts", d.showShortcuts),
            showNotes = sp.getBoolean("ap_notes", d.showNotes),
            showQuick = sp.getBoolean("ap_quick", d.showQuick)
        )
    }

    fun saveAppearance(a: Appearance) {
        sp.edit()
            .putInt("ap_theme", a.themeMode)
            .putInt("ap_accent", a.accentIdx)
            .putInt("ap_wpKind", a.wallpaperKind)
            .putInt("ap_grad", a.gradientIdx)
            .putFloat("ap_blur", a.wpBlur)
            .putFloat("ap_dim", a.wpDim)
            .putFloat("ap_glass", a.glass)
            .putFloat("ap_gblur", a.glassBlur)
            .putInt("ap_radius", a.radius)
            .putBoolean("ap_shine", a.shine)
            .putBoolean("ap_sbglass", a.sbGlass)
            .putFloat("ap_sbop2", a.sbOpacity)
            .putFloat("ap_sbblur", a.sbBlur)
            .putInt("ap_sbtint", a.sbTint)
            .putInt("ap_sbicons", a.sbIcons)
            .putBoolean("ap_nbglass", a.nbGlass)
            .putBoolean("ap_anim", a.animations)
            .putBoolean("ap_island", a.showIsland)
            .putBoolean("ap_greeting", a.showGreeting)
            .putBoolean("ap_clock", a.showClock)
            .putBoolean("ap_clock24", a.clock24)
            .putBoolean("ap_date", a.showDate)
            .putBoolean("ap_privacy", a.showPrivacy)
            .putBoolean("ap_shortcuts", a.showShortcuts)
            .putBoolean("ap_notes", a.showNotes)
            .putBoolean("ap_quick", a.showQuick)
            .apply()
    }

    // ---- lists ----

    fun loadSites(key: String): MutableList<Site> {
        val out = mutableListOf<Site>()
        try {
            val a = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Site(o.getString("t"), o.getString("u")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun saveSites(key: String, list: List<Site>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("t", it.title).put("u", it.url)) }
        sp.edit().putString(key, a.toString()).apply()
    }

    fun loadDownloads(): MutableList<DownloadItem> {
        val out = mutableListOf<DownloadItem>()
        try {
            val a = JSONArray(sp.getString("downloads", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(DownloadItem(o.getString("n"), o.getString("u"), o.getLong("t")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun saveDownloads(list: List<DownloadItem>) {
        val a = JSONArray()
        list.take(200).forEach {
            a.put(JSONObject().put("n", it.name).put("u", it.url).put("t", it.time))
        }
        sp.edit().putString("downloads", a.toString()).apply()
    }

    fun loadServers(): MutableList<VpnServer> {
        val out = mutableListOf<VpnServer>()
        try {
            val a = JSONArray(sp.getString("servers", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    VpnServer(
                        o.getString("id"), o.getString("name"), o.getString("scheme"),
                        o.getString("host"), o.getInt("port"),
                        o.optString("user", ""), o.optString("pass", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun saveServers(list: List<VpnServer>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("id", it.id).put("name", it.name).put("scheme", it.scheme)
                    .put("host", it.host).put("port", it.port).put("user", it.user)
                    .put("pass", it.pass)
            )
        }
        sp.edit().putString("servers", a.toString()).apply()
    }

    fun loadTabs(): List<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(sp.getString("tabs", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (_: Exception) {
        }
        return out
    }

    fun saveTabs(urls: List<String>) {
        val a = JSONArray()
        urls.forEach { a.put(it) }
        sp.edit().putString("tabs", a.toString()).apply()
    }
}
