package com.flux.explorer

import android.content.Context
import android.net.Uri
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebResourceResponse
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.zip.ZipInputStream

data class ContentScript(
    val matches: List<String>,
    val excludes: List<String>,
    val js: List<String>,
    val css: List<String>,
    val runAt: String,
    val allFrames: Boolean
)

data class Ext(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val dir: String,
    val locale: String,
    val manifestLite: String,
    val scripts: List<ContentScript>,
    val hasBackground: Boolean,
    val hasPopup: Boolean,
    val enabled: Boolean
)

/** One piece of JavaScript to inject, plus the origins it may run on. */
data class ScriptUnit(val js: String, val origins: Set<String>)

/**
 * Runs the "content script" part of Chrome extensions inside Flux Explorer's WebView.
 *
 * Supported: manifest content_scripts (js + css, matches, exclude_matches, run_at, all_frames),
 * chrome.storage, chrome.i18n, chrome.runtime.getURL / getManifest, extension resources.
 * Not supported: background pages / service workers, toolbar popups, chrome.tabs, webRequest, etc.
 *
 * WebView has no isolated worlds, so scripts run in the page's own JavaScript world.
 */
object ExtensionManager {

    const val HOST = "flux-ext.local"

    /** Ids of enabled extensions; read by the storage bridge. */
    @Volatile
    var enabledIds: Set<String> = emptySet()

    fun extRoot(ctx: Context): File = File(ctx.filesDir, "extensions").also { it.mkdirs() }

    fun rootOf(dir: File): File? {
        if (File(dir, "manifest.json").exists()) return dir
        return dir.listFiles()?.firstOrNull { it.isDirectory && File(it, "manifest.json").exists() }
    }

    // ------------------------------------------------------------------ loading

    fun loadAll(ctx: Context, disabled: Set<String>): List<Ext> =
        (extRoot(ctx).listFiles() ?: emptyArray())
            .filter { it.isDirectory }
            .mapNotNull { d ->
                try {
                    parse(d, d.name, d.name !in disabled)
                } catch (e: Exception) {
                    null
                }
            }
            .sortedBy { it.name.lowercase() }

    private fun strings(a: JSONArray?): List<String> {
        val out = mutableListOf<String>()
        if (a != null) for (i in 0 until a.length()) out.add(a.optString(i))
        return out
    }

    fun messageMap(root: File, locale: String): JSONObject {
        val out = JSONObject()
        for (loc in listOf(locale, "en", "en_US").filter { it.isNotBlank() }.distinct()) {
            val f = File(root, "_locales/$loc/messages.json")
            if (!f.exists()) continue
            try {
                val j = JSONObject(f.readText().trimStart('\uFEFF'))
                val keys = j.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val m = j.optJSONObject(k)?.optString("message", "") ?: ""
                    if (!out.has(k)) out.put(k, m)
                }
            } catch (_: Exception) {
            }
            break
        }
        return out
    }

    private fun resolveMsg(text: String, msgs: JSONObject): String {
        if (text.startsWith("__MSG_") && text.endsWith("__") && text.length > 8) {
            val key = text.substring(6, text.length - 2)
            val v = msgs.optString(key, "")
            if (v.isNotBlank()) return v
        }
        return text
    }

    fun parse(dir: File, id: String, enabled: Boolean): Ext? {
        val root = rootOf(dir) ?: return null
        val mf = JSONObject(File(root, "manifest.json").readText().trimStart('\uFEFF'))
        val locale = mf.optString("default_locale", "")
        val msgs = messageMap(root, locale)
        val scripts = mutableListOf<ContentScript>()
        val arr = mf.optJSONArray("content_scripts")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                scripts.add(
                    ContentScript(
                        strings(o.optJSONArray("matches")),
                        strings(o.optJSONArray("exclude_matches")),
                        strings(o.optJSONArray("js")),
                        strings(o.optJSONArray("css")),
                        o.optString("run_at", "document_idle"),
                        o.optBoolean("all_frames", false)
                    )
                )
            }
        }
        val popup = (mf.optJSONObject("action")?.optString("default_popup") ?: "").isNotEmpty() ||
            (mf.optJSONObject("browser_action")?.optString("default_popup") ?: "").isNotEmpty()
        val name = resolveMsg(mf.optString("name", id), msgs)
        val version = mf.optString("version", "")
        val lite = JSONObject()
            .put("name", name)
            .put("version", version)
            .put("manifest_version", mf.optInt("manifest_version", 2))
            .put("description", resolveMsg(mf.optString("description", ""), msgs))
        return Ext(
            id = id,
            name = name,
            version = version,
            description = resolveMsg(mf.optString("description", ""), msgs),
            dir = root.path,
            locale = locale,
            manifestLite = lite.toString(),
            scripts = scripts,
            hasBackground = mf.has("background"),
            hasPopup = popup,
            enabled = enabled
        )
    }

    // ------------------------------------------------------------------ installing

    fun downloadCrx(id: String): ByteArray {
        val url = "https://clients2.google.com/service/update2/crx?response=redirect" +
            "&prodversion=120.0.6099.0&acceptformat=crx2,crx3" +
            "&x=id%3D" + id + "%26installsource%3Dondemand%26uc"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        if (c.responseCode != 200) throw Exception("Chrome Web Store answered ${c.responseCode}")
        val bytes = c.inputStream.use { it.readBytes() }
        if (bytes.size < 100) throw Exception("Extension not found in the Web Store")
        return bytes
    }

    private fun le(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) or
            ((b[o + 2].toInt() and 255) shl 16) or ((b[o + 3].toInt() and 255) shl 24)

    /** A .crx is a small header followed by a normal zip. */
    private fun stripCrx(d: ByteArray): ByteArray {
        val isCrx = d.size > 16 && d[0] == 0x43.toByte() && d[1] == 0x72.toByte() &&
            d[2] == 0x32.toByte() && d[3] == 0x34.toByte()
        if (!isCrx) return d
        val version = le(d, 4)
        val start = if (version == 3) 12 + le(d, 8) else 16 + le(d, 8) + le(d, 12)
        if (start <= 0 || start >= d.size) throw Exception("Corrupt .crx file")
        return d.copyOfRange(start, d.size)
    }

    private fun unzip(zip: ByteArray, dir: File) {
        val base = dir.canonicalFile
        var total = 0L
        ZipInputStream(ByteArrayInputStream(zip)).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val out = File(dir, e.name).canonicalFile
                if (out.path != base.path && !out.path.startsWith(base.path + File.separator)) {
                    throw Exception("Unsafe file path in archive")
                }
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { o ->
                        total += zin.copyTo(o)
                        if (total > 80_000_000L) throw Exception("Extension is too large")
                    }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
    }

    fun installBytes(ctx: Context, data: ByteArray, preferredId: String?): Ext {
        val zip = stripCrx(data)
        val id = preferredId ?: ("local" + UUID.randomUUID().toString().replace("-", "").take(12))
        val dir = File(extRoot(ctx), id)
        if (dir.exists()) dir.deleteRecursively()
        dir.mkdirs()
        try {
            unzip(zip, dir)
            return parse(dir, id, true)
                ?: throw Exception("No manifest.json found. Is this a Chrome extension (.crx or .zip)?")
        } catch (e: Exception) {
            dir.deleteRecursively()
            throw e
        }
    }

    fun remove(ctx: Context, id: String) {
        File(extRoot(ctx), id).deleteRecursively()
    }

    // ------------------------------------------------------------------ injection scripts

    private fun esc(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (".+?^\$(){}|[]\\/".indexOf(c) >= 0) sb.append('\\')
            sb.append(c)
        }
        return sb.toString()
    }

    /** Chrome match pattern -> JavaScript regular expression source. */
    private fun patternToRegex(p: String): String? {
        if (p == "<all_urls>") return "^(https?|file|ftp)://.*"
        val m = Regex("^(\\*|https?|file|ftp)://([^/]*)(/.*)$").matchEntire(p) ?: return null
        val scheme = if (m.groupValues[1] == "*") "https?" else m.groupValues[1]
        val host = m.groupValues[2]
        val path = m.groupValues[3]
        val hostRe = when {
            host == "*" || host.isEmpty() -> "[^/]*"
            host.startsWith("*.") -> "([^/]+\\.)?" + esc(host.substring(2))
            else -> esc(host)
        }
        val pathRe = path.split("*").joinToString(".*") { esc(it) }
        return "^" + scheme + ":\\/\\/" + hostRe + pathRe + "$"
    }

    private fun originsFor(matches: List<String>): Set<String> {
        if (matches.isEmpty()) return setOf("*")
        val out = LinkedHashSet<String>()
        for (m in matches) {
            if (m == "<all_urls>") return setOf("*")
            val r = Regex("^(\\*|https?|file|ftp)://([^/]*)(/.*)$").matchEntire(m) ?: continue
            val scheme = r.groupValues[1]
            val host = r.groupValues[2]
            if (host == "*" || host.isEmpty() || scheme == "file" || scheme == "ftp") return setOf("*")
            val schemes = if (scheme == "*") listOf("http", "https") else listOf(scheme)
            for (s in schemes) {
                out.add("$s://$host")
                if (host.startsWith("*.")) out.add("$s://" + host.substring(2))
            }
        }
        return if (out.isEmpty()) setOf("*") else out
    }

    private fun prelude(cs: ContentScript): String {
        val inc = JSONArray(cs.matches.mapNotNull { patternToRegex(it) }).toString()
        val exc = JSONArray(cs.excludes.mapNotNull { patternToRegex(it) }).toString()
        return "if(window!==window.top&&" + (!cs.allFrames) + ")return;\n" +
            "var __u=location.href,__ok=false,__m=" + inc + ",__x=" + exc + ";\n" +
            "for(var __i=0;__i<__m.length;__i++){if(new RegExp(__m[__i]).test(__u)){__ok=true;break;}}\n" +
            "if(!__ok)return;\n" +
            "for(var __j=0;__j<__x.length;__j++){if(new RegExp(__x[__j]).test(__u))return;}\n"
    }

    private val SHIM = """
var chrome=(function(){
var ID=__ID__,MSGS=__MSGS__,MF=__MF__;
var B=window.__fluxExt;
function load(a){try{return JSON.parse(B.get(ID,a)||'{}');}catch(e){return {};}}
function save(a,o){try{B.set(ID,a,JSON.stringify(o));}catch(e){}}
function ev(){return {addListener:function(){},removeListener:function(){},hasListener:function(){return false;}};}
function done(args,val){var cb=args.length&&typeof args[args.length-1]==='function'?args[args.length-1]:null;if(cb){setTimeout(function(){cb(val);},0);return undefined;}return Promise.resolve(val);}
function area(name){return {
get:function(keys){var data=load(name);var out={};
 if(keys==null||typeof keys==='function'){for(var k in data)out[k]=data[k];}
 else if(typeof keys==='string'){if(keys in data)out[keys]=data[keys];}
 else if(Array.isArray(keys)){keys.forEach(function(k){if(k in data)out[k]=data[k];});}
 else{for(var d in keys){out[d]=(d in data)?data[d]:keys[d];}}
 return done(arguments,out);},
set:function(items){var data=load(name);for(var k in items)data[k]=items[k];save(name,data);return done(arguments,undefined);},
remove:function(keys){var data=load(name);[].concat(keys).forEach(function(k){delete data[k];});save(name,data);return done(arguments,undefined);},
clear:function(){save(name,{});return done(arguments,undefined);},
getBytesInUse:function(){return done(arguments,0);}
};}
var url=function(p){return 'https://flux-ext.local/'+ID+'/'+String(p||'').replace(/^\//,'');};
return {
runtime:{id:ID,getManifest:function(){return MF;},getURL:url,
 sendMessage:function(){var a=arguments;var cb=typeof a[a.length-1]==='function'?a[a.length-1]:null;if(cb){setTimeout(function(){cb(undefined);},0);return undefined;}return Promise.resolve(undefined);},
 connect:function(){return {name:'',postMessage:function(){},disconnect:function(){},onMessage:ev(),onDisconnect:ev()};},
 onMessage:ev(),onConnect:ev(),onInstalled:ev(),lastError:undefined,
 getPlatformInfo:function(cb){var r={os:'android',arch:'arm'};if(cb){cb(r);return;}return Promise.resolve(r);}},
extension:{getURL:url},
storage:{local:area('local'),sync:area('sync'),session:area('session'),managed:area('managed'),onChanged:ev()},
i18n:{getMessage:function(k){return MSGS[k]!==undefined?MSGS[k]:'';},getUILanguage:function(){return navigator.language;}}
};
})();
"""

    private fun readFile(root: File, rel: String): String? {
        return try {
            val f = File(root, rel.trimStart('/'))
            if (!f.canonicalPath.startsWith(root.canonicalPath + File.separator)) return null
            if (!f.isFile || f.length() > 4_000_000L) return null
            f.readText().trimStart('\uFEFF')
        } catch (e: Exception) {
            null
        }
    }

    /** Builds every injectable script of the given (enabled) extensions. */
    fun units(exts: List<Ext>): List<ScriptUnit> {
        val out = mutableListOf<ScriptUnit>()
        for (e in exts) {
            val root = File(e.dir)
            val msgs = messageMap(root, e.locale).toString()
            val shim = SHIM
                .replace("__ID__", JSONObject.quote(e.id))
                .replace("__MSGS__", msgs)
                .replace("__MF__", e.manifestLite)
            for (cs in e.scripts) {
                val origins = originsFor(cs.matches)
                val pre = prelude(cs)
                val run = if (cs.runAt == "document_start") {
                    "__go();"
                } else {
                    "if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',__go);}else{__go();}"
                }
                for (f in cs.js) {
                    val code = readFile(root, f) ?: continue
                    val js = "(function(){try{\n" + pre + shim +
                        "\nvar __run=function(chrome,browser){\n" + code + "\n};\n" +
                        "var __go=function(){try{__run(chrome,chrome);}catch(e){console.error('[Flux extension]',e);}};\n" +
                        run + "\n}catch(e){}})();"
                    out.add(ScriptUnit(js, origins))
                }
                for (f in cs.css) {
                    val css = readFile(root, f) ?: continue
                    val js = "(function(){try{\n" + pre +
                        "var s=document.createElement('style');s.setAttribute('data-flux-ext'," + JSONObject.quote(e.id) + ");" +
                        "s.textContent=" + JSONObject.quote(css) + ";\n" +
                        "var add=function(){var p=document.head||document.documentElement;if(!p)return false;p.appendChild(s);return true;};\n" +
                        "if(!add()){var iv=setInterval(function(){if(add())clearInterval(iv);},5);setTimeout(function(){clearInterval(iv);},5000);}\n" +
                        "}catch(e){}})();"
                    out.add(ScriptUnit(js, origins))
                }
            }
        }
        return out
    }

    // ------------------------------------------------------------------ extension files for chrome.runtime.getURL

    fun serve(ctx: Context, uri: Uri): WebResourceResponse {
        val cors = mapOf("Access-Control-Allow-Origin" to "*")
        val notFound = WebResourceResponse(
            "text/plain", "UTF-8", 404, "Not Found", cors, ByteArrayInputStream(ByteArray(0))
        )
        val segs = uri.pathSegments
        if (segs.size < 2) return notFound
        val id = segs[0]
        if (!id.matches(Regex("[A-Za-z0-9]+"))) return notFound
        val root = rootOf(File(extRoot(ctx), id)) ?: return notFound
        return try {
            val f = File(root, segs.drop(1).joinToString("/"))
            if (!f.canonicalPath.startsWith(root.canonicalPath + File.separator) || !f.isFile) return notFound
            val ext = f.extension.lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
                "js", "mjs" -> "text/javascript"
                "json" -> "application/json"
                "woff2" -> "font/woff2"
                "woff" -> "font/woff"
                else -> "application/octet-stream"
            }
            WebResourceResponse(mime, null, 200, "OK", cors, FileInputStream(f))
        } catch (e: Exception) {
            notFound
        }
    }
}

/** Storage backend for chrome.storage (exposed to pages as window.__fluxExt). */
class ExtBridge(ctx: Context) {
    private val sp = ctx.getSharedPreferences("flux_ext_storage", Context.MODE_PRIVATE)

    @JavascriptInterface
    fun get(id: String, area: String): String {
        if (id !in ExtensionManager.enabledIds) return "{}"
        return sp.getString("$id:$area", "{}") ?: "{}"
    }

    @JavascriptInterface
    fun set(id: String, area: String, json: String) {
        if (id !in ExtensionManager.enabledIds || json.length > 1_500_000) return
        sp.edit().putString("$id:$area", json).apply()
    }
}
