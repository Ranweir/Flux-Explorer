package com.flux.explorer.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PrivacyTip
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.TravelExplore
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flux.explorer.BrowserViewModel
import com.flux.explorer.Overlay
import androidx.compose.material.icons.outlined.Palette
import com.flux.explorer.VpnState

// =====================================================================
//  VPN  (reference screen 3: hero on top, sheet with details, big button)
// =====================================================================

@Composable
fun VpnScreen(vm: BrowserViewModel) {
    val p = P
    var showAdd by remember { mutableStateOf(false) }
    val state = vm.vpnState
    val on = state == VpnState.On

    val inf = rememberInfiniteTransition(label = "pulse")
    val ringScale by inf.animateFloat(
        initialValue = 1f, targetValue = 1.7f,
        animationSpec = infiniteRepeatable(tween(1900, easing = LinearEasing), RepeatMode.Restart),
        label = "ringScale"
    )
    val ringAlpha by inf.animateFloat(
        initialValue = 0.35f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1900, easing = LinearEasing), RepeatMode.Restart),
        label = "ringAlpha"
    )

    Box(Modifier.fillMaxSize().background(p.bg)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            // hero
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(p.navy, p.navy2)))
            ) {
                Box(
                    Modifier.fillMaxWidth().statusBarsPadding().height(270.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .size(120.dp)
                            .graphicsLayer {
                                scaleX = ringScale
                                scaleY = ringScale
                                this.alpha = if (on && p.anim) ringAlpha else 0f
                            }
                            .background(Color.White, CircleShape)
                    )
                    Box(
                        Modifier.size(124.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.Shield, null,
                            tint = if (on) p.good else Color.White,
                            modifier = Modifier.size(66.dp)
                        )
                    }
                }
            }

            // sheet
            Column(
                Modifier
                    .fillMaxWidth()
                    .offset(y = (-28).dp)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(p.bg)
                    .padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 190.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Secure VPN", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Browser proxy · hides your IP", color = p.muted, fontSize = 13.sp)
                    }
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(p.card)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(8.dp).clip(CircleShape).background(
                                when (state) {
                                    VpnState.On -> p.good
                                    VpnState.Connecting -> Color(0xFFF5A524)
                                    VpnState.Error -> p.bad
                                    VpnState.Off -> p.muted
                                }
                            )
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            when (state) {
                                VpnState.On -> "Connected"
                                VpnState.Connecting -> "Connecting…"
                                VpnState.Error -> "Error"
                                VpnState.Off -> "Not connected"
                            },
                            color = p.text, fontSize = 12.sp
                        )
                    }
                }

                if (on && vm.activeServerName.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text("Routing through ${vm.activeServerName}", color = p.good, fontSize = 13.sp)
                }
                if (state == VpnState.Error && vm.vpnMessage.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(vm.vpnMessage, color = p.bad, fontSize = 13.sp)
                }

                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Feature(Icons.Outlined.VisibilityOff, "Hide IP")
                    Feature(Icons.Outlined.Public, "Any region")
                    Feature(Icons.Outlined.Bolt, "One tap")
                    Feature(Icons.Outlined.Lock, "HTTPS proxy")
                }

                Spacer(Modifier.height(22.dp))
                SectionTitle("Overview")
                Spacer(Modifier.height(6.dp))
                Text(
                    "Flux VPN sends everything you browse in Flux Explorer through the proxy server you pick, so websites see the server's IP instead of yours. " +
                        "Like the VPN in Opera, it protects this browser only, not other apps. Downloads started from a page use your normal connection.",
                    color = p.muted, fontSize = 13.sp, lineHeight = 19.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Check my IP",
                    color = p.accent, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable { vm.go("https://api.ipify.org") }.padding(vertical = 6.dp)
                )

                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("Servers", Modifier.weight(1f))
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(p.sky)
                            .clickable { showAdd = true }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.Add, null, tint = p.accent, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Add", color = p.accent, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
                Spacer(Modifier.height(10.dp))

                if (vm.servers.isEmpty()) {
                    FxCard(color = p.sky, radius = 20.dp) {
                        Column(Modifier.padding(16.dp)) {
                            Text("No servers yet", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Add the HTTP or HTTPS proxy you want to use (your own server or one from a proxy provider), then tap Connect.",
                                color = p.muted, fontSize = 12.sp, lineHeight = 17.sp
                            )
                        }
                    }
                } else {
                    vm.servers.forEach { s ->
                        val selected = s.id == vm.selectedServerId
                        FxCard(
                            Modifier
                                .padding(bottom = 10.dp)
                                .clickable {
                                    if (vm.vpnState == VpnState.On) vm.disconnectVpn()
                                    vm.selectServer(s.id)
                                },
                            color = if (selected) p.sky else p.card,
                            radius = 20.dp
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(40.dp).clip(CircleShape).background(if (selected) p.card else p.sky),
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Outlined.Dns, null, tint = p.accent, modifier = Modifier.size(20.dp)) }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        s.name, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "${s.scheme}://${s.host}:${s.port}", color = p.muted, fontSize = 12.sp,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Icon(
                                    Icons.Outlined.Delete, "Remove", tint = p.muted,
                                    modifier = Modifier.size(22.dp).clickable { vm.removeServer(s.id) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // connect button
        val label = when (state) {
            VpnState.On -> "Disconnect"
            VpnState.Connecting -> "Connecting…"
            else -> "Connect"
        }
        val sub = when {
            vm.servers.isEmpty() -> "Add a server to start"
            else -> (vm.servers.firstOrNull { it.id == vm.selectedServerId } ?: vm.servers.first()).name
        }
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(start = 20.dp, end = 20.dp, bottom = 96.dp)
                .fillMaxWidth()
                .height(66.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(navyBrush())
                .clickable(enabled = state != VpnState.Connecting) {
                    when {
                        vm.servers.isEmpty() -> showAdd = true
                        state == VpnState.On -> vm.disconnectVpn()
                        else -> vm.connectVpn()
                    }
                }
        ) {
            Column(Modifier.align(Alignment.CenterStart).padding(start = 24.dp)) {
                Text(label, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(sub, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, maxLines = 1)
            }
            ArrowButton(Modifier.align(Alignment.CenterEnd).padding(end = 14.dp), size = 44.dp)
        }
    }

    if (showAdd) {
        AddServerDialog(
            onDismiss = { showAdd = false },
            onSave = { name, scheme, host, port, user, pass ->
                vm.addServer(name, scheme, host, port, user, pass)
                showAdd = false
            }
        )
    }
}

@Composable
private fun Feature(icon: ImageVector, label: String) {
    val p = P
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(p.card),
            contentAlignment = Alignment.Center
        ) { Icon(icon, label, tint = p.accent, modifier = Modifier.size(24.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = p.muted, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun AddServerDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, Int, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("") }
    var scheme by remember { mutableStateOf("https") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val portNum = port.toIntOrNull()
    val valid = host.isNotBlank() && portNum != null && portNum in 1..65535

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add proxy server") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    name, { name = it }, label = { Text("Name (e.g. Germany)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    host, { host = it.trim() }, label = { Text("Host") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    port, { port = it.filter { c -> c.isDigit() }.take(5) }, label = { Text("Port") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = scheme == "https", onClick = { scheme = "https" }, label = { Text("HTTPS") })
                    FilterChip(selected = scheme == "http", onClick = { scheme = "http" }, label = { Text("HTTP") })
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    user, { user = it }, label = { Text("Username (optional)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    pass, { pass = it }, label = { Text("Password (optional)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    onSave(name.ifBlank { host }, scheme, host, portNum ?: 0, user, pass)
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// =====================================================================
//  SETTINGS
// =====================================================================

@Composable
fun SettingsScreen(vm: BrowserViewModel) {
    val p = P
    var engineMenu by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 120.dp)
    ) {
        Text("Settings", color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))

        SectionTitle("Personalise")
        Spacer(Modifier.height(10.dp))
        FxCard {
            ActionRow(
                Icons.Outlined.Palette, "Appearance",
                "Theme, wallpaper, liquid glass, home layout"
            ) { vm.overlay = Overlay.Appearance }
        }

        Spacer(Modifier.height(20.dp))
        SectionTitle("Protection")
        Spacer(Modifier.height(10.dp))
        FxCard {
            Column(Modifier.padding(vertical = 6.dp)) {
                ToggleRow(Icons.Outlined.Block, "Ad blocker", "Blocks ad networks and ad requests", vm.adBlock) { vm.changeAdBlock(it) }
                ToggleRow(Icons.Outlined.PrivacyTip, "Block trackers", "Stops analytics and tracking scripts", vm.trackerBlock) { vm.changeTrackerBlock(it) }
                ToggleRow(Icons.Outlined.VisibilityOff, "Hide ad spaces", "Removes empty ad boxes on pages", vm.cosmetic) { vm.changeCosmetic(it) }
                ToggleRow(Icons.Outlined.TravelExplore, "Block pop-ups", "Stops pages opening windows by themselves", vm.popupBlock) { vm.changePopupBlock(it) }
            }
        }

        Spacer(Modifier.height(20.dp))
        SectionTitle("Browsing")
        Spacer(Modifier.height(10.dp))
        FxCard {
            Column(Modifier.padding(vertical = 6.dp)) {
                ToggleRow(Icons.Outlined.Code, "JavaScript", "Turn off only if a page misbehaves", vm.jsEnabled) { vm.setJs(it) }
                ToggleRow(Icons.Outlined.Lock, "Block third-party cookies", "Limits cross-site tracking", vm.noThirdPartyCookies) { vm.changeNoThirdPartyCookies(it) }
                Box {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { engineMenu = true }
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RowIcon(Icons.Outlined.TravelExplore)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Search engine", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text(vm.engine, color = p.muted, fontSize = 12.sp)
                        }
                    }
                    DropdownMenu(expanded = engineMenu, onDismissRequest = { engineMenu = false }) {
                        BrowserViewModel.engines.keys.forEach { name ->
                            DropdownMenuItem(
                                text = { Text(if (name == vm.engine) "✓  $name" else name) },
                                onClick = {
                                    vm.changeEngine(name)
                                    engineMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        SectionTitle("Data")
        Spacer(Modifier.height(10.dp))
        FxCard {
            Column(Modifier.padding(vertical = 6.dp)) {
                ActionRow(Icons.Outlined.Refresh, "Update filter lists", vm.filterStatus) { vm.updateFilters() }
                ActionRow(Icons.Outlined.CleaningServices, "Clear history", "${vm.history.size} pages") { vm.clearHistory() }
                ActionRow(Icons.Outlined.Delete, "Clear cache & cookies", "Signs you out of websites") { vm.clearCacheAndCookies() }
            }
        }

        Spacer(Modifier.height(24.dp))
        Text(
            "Flux Explorer 1.1.0",
            color = p.muted, fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth(),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
private fun RowIcon(icon: ImageVector) {
    val p = P
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(p.sky),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = p.accent, modifier = Modifier.size(20.dp)) }
}

@Composable
private fun ToggleRow(icon: ImageVector, title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = P
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RowIcon(icon)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = p.muted, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = p.accent,
                checkedThumbColor = Color.White
            )
        )
    }
}

@Composable
private fun ActionRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    val p = P
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RowIcon(icon)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = p.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
