package com.flux.explorer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Finds free public HTTP proxies and keeps only the ones that really work.
 *
 * Every candidate is tested from the phone itself: a real HTTPS request (through the proxy's
 * CONNECT tunnel) to a Google connectivity endpoint must return 204. A proxy that fails,
 * is slow, or tampers with TLS (certificate errors) is dropped.
 */
object FreeProxies {

    data class Found(val host: String, val port: Int, val ms: Long)

    private val SOURCES = listOf(
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
        "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt"
    )

    private val LINE = Regex("^(?:https?://)?(\\d{1,3}(?:\\.\\d{1,3}){3}):(\\d{2,5})$")

    private fun download(url: String): List<String> = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 12000
        if (c.responseCode != 200) emptyList() else c.inputStream.bufferedReader().readLines()
    } catch (e: Exception) {
        emptyList()
    }

    private fun test(host: String, port: Int): Long {
        val start = System.currentTimeMillis()
        return try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress.createUnresolved(host, port))
            val c = URL("https://www.gstatic.com/generate_204").openConnection(proxy) as HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 5000
            c.instanceFollowRedirects = false
            try {
                if (c.responseCode == 204) System.currentTimeMillis() - start else -1L
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            -1L
        }
    }

    /** Returns up to [want] working proxies, fastest first. Takes up to about a minute. */
    suspend fun find(want: Int): List<Found> {
        val candidates = withContext(Dispatchers.IO) {
            val set = LinkedHashSet<Pair<String, Int>>()
            for (src in SOURCES) {
                for (line in download(src)) {
                    val m = LINE.matchEntire(line.trim()) ?: continue
                    val port = m.groupValues[2].toIntOrNull() ?: continue
                    if (port in 1..65535) set.add(m.groupValues[1] to port)
                }
            }
            set.toList().shuffled().take(150)
        }
        if (candidates.isEmpty()) return emptyList()

        val ok = ConcurrentLinkedQueue<Found>()
        val gate = Semaphore(24)
        withTimeoutOrNull(45_000) {
            coroutineScope {
                candidates.map { c ->
                    async(Dispatchers.IO) {
                        gate.withPermit {
                            val ms = test(c.first, c.second)
                            if (ms >= 0) ok.add(Found(c.first, c.second, ms))
                        }
                    }
                }.awaitAll()
            }
        }
        return ok.sortedBy { it.ms }.take(want)
    }
}
