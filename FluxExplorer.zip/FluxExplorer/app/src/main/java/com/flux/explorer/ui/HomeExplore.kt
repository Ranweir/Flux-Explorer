package com.flux.explorer.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.PrivacyTip
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.TravelExplore
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.VpnLock
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flux.explorer.BrowserViewModel
import com.flux.explorer.Overlay
import com.flux.explorer.VpnState
import java.text.NumberFormat
import java.util.Calendar

private fun fmt(n: Long): String = NumberFormat.getInstance().format(n)

// =====================================================================
//  HOME  (reference screen 1)
// =====================================================================

@Composable
fun HomeScreen(vm: BrowserViewModel) {
    val p = P
    var query by remember { mutableStateOf("") }
    val greeting = remember {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when {
            h < 12 -> "Good Morning,"
            h < 17 -> "Good Afternoon,"
            else -> "Good Evening,"
        }
    }
    val vpnOn = vm.vpnState == VpnState.On
    val current = vm.current

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 120.dp)
    ) {
        // top row: logo + tab counter
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(p.sky),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Shield, null, tint = p.accent, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.card)
                    .clickable { vm.overlay = Overlay.Tabs },
                contentAlignment = Alignment.Center
            ) {
                Text(vm.tabs.size.toString(), color = p.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(greeting, color = p.muted, fontSize = 14.sp)
        Text("Flux Explorer", color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(16.dp))
        SearchPill(
            value = query,
            onValueChange = { query = it },
            placeholder = "Search or type a URL",
            onGo = {
                vm.go(query)
                query = ""
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(18.dp))

        // navy hero card
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(26.dp))
                .background(navyBrush())
                .padding(22.dp)
        ) {
            Icon(
                Icons.Filled.Shield, null,
                tint = Color.White.copy(alpha = 0.10f),
                modifier = Modifier.size(150.dp).align(Alignment.CenterEnd)
            )
            Column {
                Text("Threats blocked", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                Text(
                    fmt(vm.totalAds + vm.totalTrackers),
                    color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold
                )
                Text("Ads & trackers since install", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusChip(if (vm.adBlock) "Ad blocker on" else "Ad blocker off", vm.adBlock)
                    StatusChip(if (vpnOn) "VPN on" else "VPN off", vpnOn)
                }
            }
        }

        // continue browsing
        if (current != null && current.url.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            FxCard(Modifier.clickable { vm.browserOpen = true }) {
                Row(
                    Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(p.sky),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Outlined.Language, null, tint = p.accent, modifier = Modifier.size(20.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Continue browsing", color = p.muted, fontSize = 12.sp)
                        Text(
                            current.title.ifBlank { current.host },
                            color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    ArrowButtonDark()
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // privacy overview (light-blue card like "Health Overview")
        FxCard(color = p.sky) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Privacy Overview", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("All time", color = p.muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth()) {
                    ColumnStat(fmt(vm.totalAds), "Ads blocked", Icons.Outlined.Block, Modifier.weight(1f))
                    ColumnStat(fmt(vm.totalTrackers), "Trackers", Icons.Outlined.PrivacyTip, Modifier.weight(1f))
                    ColumnStat(if (vpnOn) "On" else "Off", "VPN", Icons.Outlined.VpnLock, Modifier.weight(1f))
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // quick access
        FxCard {
            Column(Modifier.padding(18.dp)) {
                Text("Quick Access", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    QuickItem(Icons.Outlined.BookmarkBorder, "Bookmarks", true) { vm.overlay = Overlay.Bookmarks }
                    QuickItem(Icons.Outlined.History, "History", false) { vm.overlay = Overlay.History }
                    QuickItem(Icons.Outlined.Download, "Downloads", false) { vm.overlay = Overlay.Downloads }
                    QuickItem(Icons.Outlined.VisibilityOff, "Private", false) { vm.newTab(incognito = true) }
                }
            }
        }
    }
}

@Composable
private fun QuickItem(icon: ImageVector, label: String, highlighted: Boolean, onClick: () -> Unit) {
    val p = P
    Column(
        Modifier.clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(if (highlighted) p.sky else p.bg)
                .border(BorderStroke(1.dp, if (highlighted) p.accent.copy(alpha = 0.35f) else Color.Transparent), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = if (highlighted) p.accent else p.muted, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = p.text, fontSize = 11.sp, maxLines = 1)
    }
}

// =====================================================================
//  EXPLORE  (reference screen 2)
// =====================================================================

@Composable
fun ExploreScreen(vm: BrowserViewModel) {
    val p = P
    var query by remember { mutableStateOf("") }
    var engineMenu by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        // navy header
        Column(
            Modifier
                .fillMaxWidth()
                .background(p.navy)
                .statusBarsPadding()
                .padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 40.dp)
        ) {
            Text("Explore The Web", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
            Text("Safely", color = Color(0xFFA9C7F5), fontSize = 28.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                SearchPill(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = "Search sites, topics…",
                    onGo = {
                        vm.go(query)
                        query = ""
                    },
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(10.dp))
                Box {
                    CircleIcon(
                        Icons.Outlined.Tune, { engineMenu = true },
                        size = 52.dp, bg = p.navy2, tint = Color.White
                    )
                    DropdownMenu(expanded = engineMenu, onDismissRequest = { engineMenu = false }) {
                        BrowserViewModel.engines.keys.forEach { name ->
                            DropdownMenuItem(
                                text = { Text(if (name == vm.engine) "✓  $name" else name) },
                                onClick = {
                                    vm.setEngine(name)
                                    engineMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // rounded sheet overlapping the header
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(p.bg)
                .verticalScroll(rememberScrollState())
                .padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 120.dp)
        ) {
            // big featured card
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF2B63B8), Color(0xFF0B1F3F))))
                    .clickable { vm.go("https://news.google.com") }
            ) {
                Box(
                    Modifier
                        .size(190.dp)
                        .align(Alignment.TopEnd)
                        .padding(top = 0.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.07f))
                )
                Icon(
                    Icons.Outlined.TravelExplore, null,
                    tint = Color.White.copy(alpha = 0.18f),
                    modifier = Modifier.size(110.dp).align(Alignment.CenterEnd).padding(end = 18.dp)
                )
                Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                    Text("Trending Now", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("News, headlines & stories", color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
                }
                ArrowButton(Modifier.align(Alignment.BottomEnd).padding(14.dp))
            }

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SmallFeatureCard(
                    "Videos", "YouTube", Icons.Outlined.PlayCircle,
                    Brush.linearGradient(listOf(Color(0xFF1D4E89), Color(0xFF0B1F3F))),
                    Modifier.weight(1f)
                ) { vm.go("https://m.youtube.com") }
                SmallFeatureCard(
                    "Shopping", "Amazon", Icons.Outlined.ShoppingBag,
                    Brush.linearGradient(listOf(Color(0xFF254A80), Color(0xFF12294D))),
                    Modifier.weight(1f)
                ) { vm.go("https://www.amazon.com") }
            }

            Spacer(Modifier.height(12.dp))
            FxCard(color = p.sky, radius = 20.dp, modifier = Modifier.clickable { vm.mainTab = MainTab.Vpn }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Browse privately", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text("Turn on VPN to hide your IP", color = p.muted, fontSize = 12.sp)
                    }
                    ArrowButtonDark()
                }
            }

            Spacer(Modifier.height(20.dp))
            SectionTitle("Popular sites")
            Spacer(Modifier.height(10.dp))
            val sites = listOf(
                "Wikipedia" to "https://www.wikipedia.org",
                "Reddit" to "https://www.reddit.com",
                "GitHub" to "https://github.com",
                "X" to "https://x.com",
                "Gmail" to "https://mail.google.com",
                "Maps" to "https://maps.google.com"
            )
            sites.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (name, url) ->
                        SiteChip(name, Modifier.weight(1f)) { vm.go(url) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallFeatureCard(
    title: String,
    sub: String,
    icon: ImageVector,
    brush: Brush,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier
            .height(130.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(brush)
            .clickable { onClick() }
    ) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.padding(14.dp).size(28.dp))
        Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
        }
        ArrowButton(Modifier.align(Alignment.BottomEnd).padding(10.dp), size = 34.dp)
    }
}

@Composable
private fun SiteChip(name: String, modifier: Modifier, onClick: () -> Unit) {
    val p = P
    Row(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(p.card)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(28.dp).clip(CircleShape).background(p.sky),
            contentAlignment = Alignment.Center
        ) { Text(name.take(1), color = p.accent, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        Spacer(Modifier.width(8.dp))
        Text(name, color = p.text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
