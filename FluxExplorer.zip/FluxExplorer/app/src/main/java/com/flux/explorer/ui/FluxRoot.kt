package com.flux.explorer.ui

import android.app.Activity
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.ui.graphics.RectangleShape
import android.os.Build
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import android.view.View
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.flux.explorer.BrowserViewModel
import com.flux.explorer.Overlay

@Composable
fun FluxRoot(vm: BrowserViewModel) {
    val p = P
    val view = LocalView.current
    val fullscreen = vm.fullscreenView

    // status-bar icon colour: dark icons only on the light screens
    val darkIcons = !p.dark && fullscreen == null && vm.overlay == Overlay.None && vm.ap.wallpaperKind == 0 &&
        (vm.browserOpen || vm.mainTab == MainTab.Home || vm.mainTab == MainTab.Settings)
    // frosted bars: only on screens that don't have their own coloured header reaching the top
    val barsStripVisible = fullscreen == null && vm.overlay == Overlay.None &&
        (vm.browserOpen || vm.mainTab == MainTab.Home || vm.mainTab == MainTab.Settings)
    val sbOn = vm.ap.sbGlass && barsStripVisible
    val tintIsLight = when (vm.ap.sbTint) {
        1 -> true
        2, 3 -> false
        else -> !p.dark
    }
    val statusIconsDark = when (vm.ap.sbIcons) {
        1 -> false
        2 -> true
        else -> if (sbOn && vm.ap.sbOpacity > 0.35f) tintIsLight else darkIcons
    }
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        val ctrl = WindowCompat.getInsetsController(window, view)
        ctrl.isAppearanceLightStatusBars = statusIconsDark
        ctrl.isAppearanceLightNavigationBars = !p.dark && vm.ap.wallpaperKind == 0
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
    }

    // immersive mode while a video is fullscreen
    LaunchedEffect(fullscreen) {
        val window = (view.context as? Activity)?.window ?: return@LaunchedEffect
        val c = WindowInsetsControllerCompat(window, view)
        if (fullscreen != null) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    BackHandler(
        enabled = fullscreen != null || vm.overlay != Overlay.None || vm.browserOpen || vm.mainTab != MainTab.Home
    ) { vm.onBack() }

    val ap = vm.ap
    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    val backdrop = GlassBackdrop(
        bitmap = if (ap.wallpaperKind == 2) vm.glassBitmap else null,
        width = rootSize.width.toFloat(),
        height = rootSize.height.toFloat(),
        dim = ap.wpDim
    )
    CompositionLocalProvider(LocalGlass provides backdrop) {
    Box(Modifier.fillMaxSize().onSizeChanged { rootSize = it }.background(p.baseBg)) {
        // ---- wallpaper ----
        if (ap.wallpaperKind == 1) {
            val g = WallpaperGradients[ap.gradientIdx.coerceIn(0, WallpaperGradients.lastIndex)]
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(g.colors)))
        } else if (ap.wallpaperKind == 2) {
            val bmp = vm.wallpaper
            if (bmp != null) {
                val blurMod = if (ap.wpBlur > 0.5f) {
                    Modifier.clipToBounds().blur(ap.wpBlur.dp, BlurredEdgeTreatment.Unbounded)
                } else Modifier
                Image(
                    bitmap = bmp, contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().then(blurMod)
                )
            }
        }
        if (ap.wallpaperKind != 0 && ap.wpDim > 0f) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = ap.wpDim)))
        }

        if (vm.browserOpen) {
            BrowserScreen(vm)
        } else {
            Box(Modifier.fillMaxSize()) {
                when (vm.mainTab) {
                    MainTab.Home -> HomeScreen(vm)
                    MainTab.Explore -> ExploreScreen(vm)
                    MainTab.Vpn -> VpnScreen(vm)
                    MainTab.Settings -> SettingsScreen(vm)
                }
                FxBottomBar(
                    selected = vm.mainTab,
                    onSelect = { vm.mainTab = it },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }

        if (vm.overlay != Overlay.None) OverlayScreen(vm)

        // ---- frosted status bar / navigation bar ----
        val barTint = when (ap.sbTint) {
            1 -> Color.White
            2 -> Color.Black
            3 -> p.navy
            else -> p.baseBg
        }.copy(alpha = ap.sbOpacity)
        if (sbOn) {
            val h = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
            if (h > 0.dp) {
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .height(h)
                        .glassSurface(RectangleShape, barTint, edge = false)
                )
            }
        }
        if (ap.nbGlass && barsStripVisible) {
            val h = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
            if (h > 0.dp) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(h)
                        .glassSurface(RectangleShape, barTint, edge = false)
                )
            }
        }

        if (fullscreen != null) FullscreenHost(fullscreen)
    }
    }
}

@Composable
private fun FullscreenHost(v: View) {
    AndroidView(
        factory = {
            (v.parent as? ViewGroup)?.removeView(v)
            v
        },
        modifier = Modifier.fillMaxSize().background(Color.Black)
    )
}
