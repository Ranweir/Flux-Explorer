package com.flux.explorer.ui

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.flux.explorer.BrowserViewModel
import com.flux.explorer.Overlay

@Composable
fun FluxRoot(vm: BrowserViewModel) {
    val p = P
    val view = LocalView.current
    val fullscreen = vm.fullscreenView

    // status-bar icon colour: dark icons only on the light screens
    val darkIcons = !p.dark && fullscreen == null && vm.overlay == Overlay.None &&
        (vm.browserOpen || vm.mainTab == MainTab.Home || vm.mainTab == MainTab.Settings)
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = darkIcons
    }

    // immersive mode while a video is fullscreen
    LaunchedEffect(fullscreen) {
        val window = (view.context as? Activity)?.window ?: return@LaunchedEffect
        val c = WindowInsetsControllerCompat(window, view)
        if (fullscreen != null) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    BackHandler(
        enabled = fullscreen != null || vm.overlay != Overlay.None || vm.browserOpen || vm.mainTab != MainTab.Home
    ) { vm.onBack() }

    val ap = vm.ap
    Box(Modifier.fillMaxSize().background(p.baseBg)) {
        // ---- wallpaper ----
        if (ap.wallpaperKind == 1) {
            val g = WallpaperGradients[ap.gradientIdx.coerceIn(0, WallpaperGradients.lastIndex)]
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(g.colors)))
        } else if (ap.wallpaperKind == 2) {
            val bmp = vm.wallpaper
            if (bmp != null) {
                val blurMod = if (ap.wpBlur > 0.5f) {
                    Modifier.clipToBounds().blur(ap.wpBlur.dp, BlurredEdgeTreatment.Unbounded)
                } else Modifier
                Image(
                    bitmap = bmp, contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().then(blurMod)
                )
            }
        }
        if (ap.wallpaperKind != 0 && ap.wpDim > 0f) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = ap.wpDim)))
        }

        if (vm.browserOpen) {
            BrowserScreen(vm)
        } else {
            Box(Modifier.fillMaxSize()) {
                when (vm.mainTab) {
                    MainTab.Home -> HomeScreen(vm)
                    MainTab.Explore -> ExploreScreen(vm)
                    MainTab.Vpn -> VpnScreen(vm)
                    MainTab.Settings -> SettingsScreen(vm)
                }
                FxBottomBar(
                    selected = vm.mainTab,
                    onSelect = { vm.mainTab = it },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }

        if (vm.overlay != Overlay.None) OverlayScreen(vm)

        if (fullscreen != null) FullscreenHost(fullscreen)
    }
}

@Composable
private fun FullscreenHost(v: View) {
    AndroidView(
        factory = {
            (v.parent as? ViewGroup)?.removeView(v)
            v
        },
        modifier = Modifier.fillMaxSize().background(Color.Black)
    )
}
