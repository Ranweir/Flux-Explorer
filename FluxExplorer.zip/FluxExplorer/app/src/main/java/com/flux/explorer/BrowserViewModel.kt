package com.flux.explorer

import android.annotation.SuppressLint
import android.app.Application
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.HttpAuthHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.flux.explorer.ui.MainTab
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.net.URLEncoder
import java.util.UUID

class BrowserTab(val id: Int, val incognito: Boolean) {
    var webView: WebView? = null
    var title by mutableStateOf("New tab")
    var url by mutableStateOf("")
    var progress by mutableFloatStateOf(0f)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var blocked by mutableIntStateOf(0)
    var desktop by mutableStateOf(false)

    val host: String
        get() = try {
            Uri.parse(url).host?.removePrefix("www.") ?: url
        } catch (e: Exception) {
            url
        }
}

class BrowserViewModel(app: Application) : AndroidViewModel(app) {

    companion object {
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        val engines = linkedMapOf(
            "DuckDuckGo" to "https://duckduckgo.com/?q=",
            "Google" to "https://www.google.com/search?q=",
            "Bing" to "https://www.bing.com/search?q=",
            "Brave" to "https://search.brave.com/search?q="
        )
    }

    private val prefs = Prefs(app)
    private val main = Handler(Looper.getMainLooper())
    private var defaultUa: String? = null
    private var nextId = 1

    // ---------- navigation state ----------
    val tabs = mutableStateListOf<BrowserTab>()
    var currentId by mutableIntStateOf(-1)
    var browserOpen by mutableStateOf(false)
    var mainTab by mutableStateOf(MainTab.Home)
    var overlay by mutableStateOf(Overlay.None)
    var fullscreenView by mutableStateOf<View?>(null)
    private var customCb: WebChromeClient.CustomViewCallback? = null

    // ---------- data ----------
    val bookmarks = mutableStateListOf<Site>()
    val history = mutableStateListOf<Site>()
    val downloads = mutableStateListOf<DownloadItem>()
    val servers = mutableStateListOf<VpnServer>()

    // ---------- settings ----------
    var adBlock by mutableStateOf(prefs.adBlock); private set
    var trackerBlock by mutableStateOf(prefs.trackerBlock); private set
    var cosmetic by mutableStateOf(prefs.cosmetic); private set
    var popupBlock by mutableStateOf(prefs.popupBlock); private set
    var jsEnabled by mutableStateOf(prefs.jsEnabled); private set
    var noThirdPartyCookies by mutableStateOf(prefs.noThirdPartyCookies); private set
    var engine by mutableStateOf(prefs.engine); private set

    // ---------- stats ----------
    var totalAds by mutableStateOf(prefs.totalAds); private set
    var totalTrackers by mutableStateOf(prefs.totalTrackers); private set
    var filterStatus by mutableStateOf(
        if (AdBlocker.extraCount > 0) "${AdBlocker.extraCount} extra hosts loaded" else "Built-in list active"
    ); private set

    // ---------- VPN ----------
    var vpnState by mutableStateOf(VpnState.Off); private set
    var vpnMessage by mutableStateOf(""); private set
    var selectedServerId by mutableStateOf(prefs.selectedServer); private set
    private var activeServer: VpnServer? = null

    // ---------- file chooser bridge (set by MainActivity) ----------
    var launchFileChooser: ((Intent) -> Unit)? = null
    var fileCallback: ValueCallback<Array<Uri>>? = null

    val current: BrowserTab?
        get() = tabs.firstOrNull { it.id == currentId }

    init {
        AdBlocker.load(app)
        filterStatus =
            if (AdBlocker.extraCount > 0) "${AdBlocker.extraCount} extra hosts loaded" else "Built-in list active"
        history.addAll(prefs.loadSites("history"))
        bookmarks.addAll(prefs.loadSites("bookmarks"))
        downloads.addAll(prefs.loadDownloads())
        servers.addAll(prefs.loadServers())
        prefs.loadTabs().forEach { u ->
            val t = BrowserTab(nextId++, false)
            t.url = u
            t.title = u
            tabs.add(t)
        }
        if (tabs.isNotEmpty()) currentId = tabs.last().id
        if (prefs.vpnOn && servers.isNotEmpty()) connectVpn()
    }

    // =====================================================================
    //  URL handling
    // =====================================================================

    fun resolve(input: String): String? {
        val t = input.trim()
        if (t.isEmpty()) return null
        if (t.startsWith("http://") || t.startsWith("https://")) return t
        val looksLikeHost = !t.contains(' ') && (t.contains('.') || t.startsWith("localhost"))
        if (looksLikeHost) return "https://$t"
        val base = engines[engine] ?: engines.values.first()
        return base + URLEncoder.encode(t, "UTF-8")
    }

    /** Loads whatever the user typed (URL or search) into the active tab and shows the browser. */
    fun go(input: String) {
        val url = resolve(input) ?: return
        val tab = current ?: newTabInternal(false).also { currentId = it.id }
        loadInTab(tab, url)
        overlay = Overlay.None
        browserOpen = true
    }

    private fun loadInTab(tab: BrowserTab, url: String) {
        val existing = tab.webView
        tab.url = url
        if (existing == null) ensureWebView(tab) else existing.loadUrl(url)
    }

    // =====================================================================
    //  Tabs
    // =====================================================================

    private fun newTabInternal(incognito: Boolean): BrowserTab {
        val t = BrowserTab(nextId++, incognito)
        tabs.add(t)
        return t
    }

    fun newTab(incognito: Boolean = false) {
        val t = newTabInternal(incognito)
        currentId = t.id
        browserOpen = false
        mainTab = MainTab.Home
        overlay = Overlay.None
    }

    fun switchTab(id: Int) {
        currentId = id
        overlay = Overlay.None
        val t = current
        if (t == null || t.url.isBlank()) {
            browserOpen = false
            mainTab = MainTab.Home
        } else {
            browserOpen = true
        }
    }

    fun closeTab(id: Int) {
        val idx = tabs.indexOfFirst { it.id == id }
        if (idx < 0) return
        val t = tabs.removeAt(idx)
        val wv = t.webView
        t.webView = null
        if (wv != null) {
            if (t.incognito) {
                try {
                    wv.clearCache(true)
                    wv.clearHistory()
                } catch (_: Exception) {
                }
            }
            (wv.parent as? ViewGroup)?.removeView(wv)
            main.post {
                try {
                    wv.destroy()
                } catch (_: Exception) {
                }
            }
        }
        if (currentId == id) {
            currentId = tabs.getOrNull(minOf(idx, tabs.size - 1))?.id ?: -1
            if (currentId == -1) {
                browserOpen = false
                mainTab = MainTab.Home
            }
        }
        saveTabs()
    }

    private fun saveTabs() {
        prefs.saveTabs(tabs.filter { !it.incognito && it.url.isNotBlank() }.map { it.url })
    }

    fun onBack() {
        when {
            fullscreenView != null -> exitFullscreen()
            overlay != Overlay.None -> overlay = Overlay.None
            browserOpen -> {
                val wv = current?.webView
                if (wv != null && wv.canGoBack()) wv.goBack() else browserOpen = false
            }
            mainTab != MainTab.Home -> mainTab = MainTab.Home
        }
    }

    fun exitFullscreen() {
        fullscreenView = null
        try {
            customCb?.onCustomViewHidden()
        } catch (_: Exception) {
        }
        customCb = null
    }

    // =====================================================================
    //  Bookmarks / history / data
    // =====================================================================

    fun isBookmarked(url: String) = bookmarks.any { it.url == url }

    fun toggleBookmark(tab: BrowserTab) {
        if (tab.url.isBlank()) return
        val existing = bookmarks.firstOrNull { it.url == tab.url }
        if (existing != null) bookmarks.remove(existing)
        else bookmarks.add(0, Site(tab.title.ifBlank { tab.url }, tab.url))
        prefs.saveSites("bookmarks", bookmarks)
    }

    fun removeBookmark(s: Site) {
        bookmarks.remove(s)
        prefs.saveSites("bookmarks", bookmarks)
    }

    fun removeHistory(s: Site) {
        history.remove(s)
        prefs.saveSites("history", history)
    }

    private fun recordHistory(title: String, url: String) {
        if (url.isBlank() || url.startsWith("about:")) return
        if (history.firstOrNull()?.url == url) return
        history.add(0, Site(title.ifBlank { url }, url))
        while (history.size > 300) history.removeAt(history.size - 1)
        prefs.saveSites("history", history)
    }

    fun clearHistory() {
        history.clear()
        prefs.saveSites("history", history)
        toast("History cleared")
    }

    fun clearCacheAndCookies() {
        tabs.forEach { it.webView?.clearCache(true) }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        toast("Cache and cookies cleared")
    }

    fun clearDownloads() {
        downloads.clear()
        prefs.saveDownloads(downloads)
    }

    // =====================================================================
    //  Settings
    // =====================================================================

    fun setAdBlock(v: Boolean) { adBlock = v; prefs.adBlock = v }
    fun setTrackerBlock(v: Boolean) { trackerBlock = v; prefs.trackerBlock = v }
    fun setCosmetic(v: Boolean) { cosmetic = v; prefs.cosmetic = v }

    fun setPopupBlock(v: Boolean) {
        popupBlock = v
        prefs.popupBlock = v
        applyToAll()
    }

    fun setJs(v: Boolean) {
        jsEnabled = v
        prefs.jsEnabled = v
        applyToAll()
        current?.webView?.reload()
    }

    fun setNoThirdPartyCookies(v: Boolean) {
        noThirdPartyCookies = v
        prefs.noThirdPartyCookies = v
        applyToAll()
    }

    fun setEngine(name: String) {
        engine = name
        prefs.engine = name
    }

    fun setDesktop(tab: BrowserTab, v: Boolean) {
        tab.desktop = v
        tab.webView?.let {
            applySettings(it, tab)
            it.reload()
        }
    }

    private fun applyToAll() {
        tabs.forEach { t -> t.webView?.let { applySettings(it, t) } }
    }

    fun updateFilters() {
        filterStatus = "Updating…"
        viewModelScope.launch {
            val n = AdBlocker.update(getApplication())
            filterStatus = if (n > 0) "Updated · $n extra hosts" else "Update failed. Check your connection."
        }
    }

    // =====================================================================
    //  VPN
    // =====================================================================

    fun addServer(name: String, scheme: String, host: String, port: Int, user: String, pass: String) {
        val s = VpnServer(UUID.randomUUID().toString(), name, scheme, host.trim(), port, user.trim(), pass)
        servers.add(s)
        prefs.saveServers(servers)
        if (selectedServerId.isBlank()) selectServer(s.id)
    }

    fun removeServer(id: String) {
        servers.removeAll { it.id == id }
        prefs.saveServers(servers)
        if (selectedServerId == id) {
            selectServer(servers.firstOrNull()?.id ?: "")
            if (vpnState == VpnState.On) disconnectVpn()
        }
    }

    fun selectServer(id: String) {
        selectedServerId = id
        prefs.selectedServer = id
    }

    fun connectVpn() {
        val server = servers.firstOrNull { it.id == selectedServerId } ?: servers.firstOrNull()
        if (server == null) {
            vpnState = VpnState.Error
            vpnMessage = "Add a proxy server first."
            return
        }
        if (!VpnManager.supported()) {
            vpnState = VpnState.Error
            vpnMessage = "This device's WebView doesn't support proxy mode. Update Android System WebView."
            return
        }
        vpnState = VpnState.Connecting
        vpnMessage = ""
        VpnManager.connect(getApplication(), server) { ok ->
            if (ok) {
                activeServer = server
                selectedServerId = server.id
                vpnState = VpnState.On
                prefs.vpnOn = true
                current?.webView?.reload()
            } else {
                vpnState = VpnState.Error
                vpnMessage = "Couldn't apply the proxy. Check host, port and scheme."
            }
        }
    }

    fun disconnectVpn() {
        VpnManager.disconnect(getApplication()) {
            activeServer = null
            vpnState = VpnState.Off
            vpnMessage = ""
            prefs.vpnOn = false
            current?.webView?.reload()
        }
    }

    val activeServerName: String
        get() = activeServer?.name ?: ""

    // =====================================================================
    //  WebView plumbing
    // =====================================================================

    fun ensureWebView(tab: BrowserTab): WebView {
        tab.webView?.let { return it }
        val wv = buildWebView(tab)
        tab.webView = wv
        if (tab.url.isNotBlank()) wv.loadUrl(tab.url)
        return wv
    }

    /** Called when the WebView is placed on screen. */
    fun attach(activityCtx: Context, tab: BrowserTab): WebView {
        val wv = ensureWebView(tab)
        (wv.parent as? ViewGroup)?.removeView(wv)
        (wv.context as? MutableContextWrapper)?.baseContext = activityCtx
        try {
            wv.onResume()
        } catch (_: Exception) {
        }
        return wv
    }

    /** Called when the WebView leaves the screen (tab switch / back to home). */
    fun detach(wv: WebView) {
        try {
            wv.onPause()
        } catch (_: Exception) {
        }
        (wv.context as? MutableContextWrapper)?.baseContext = getApplication<Application>()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebView(tab: BrowserTab): WebView {
        val wv = WebView(MutableContextWrapper(getApplication<Application>()))
        wv.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        if (defaultUa == null) defaultUa = wv.settings.userAgentString
        wv.webViewClient = FluxClient(tab)
        wv.webChromeClient = FluxChrome(tab)
        wv.setDownloadListener { url, ua, cd, mime, _ -> download(url, ua, cd, mime) }
        CookieManager.getInstance().setAcceptCookie(true)
        applySettings(wv, tab)
        return wv
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun applySettings(wv: WebView, tab: BrowserTab) {
        val s = wv.settings
        s.javaScriptEnabled = jsEnabled
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = !popupBlock
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.cacheMode = if (tab.incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        s.saveFormData = !tab.incognito
        s.userAgentString = if (tab.desktop) DESKTOP_UA else defaultUa
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, !noThirdPartyCookies)
    }

    private fun onBlocked(tab: BrowserTab, kind: Int) {
        if (kind == 1) totalAds++ else totalTrackers++
        tab.blocked++
    }

    private fun toast(msg: String) {
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }

    private fun download(url: String, ua: String?, cd: String?, mime: String?) {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("This kind of download isn't supported")
            return
        }
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (!mime.isNullOrBlank()) req.setMimeType(mime)
            if (!ua.isNullOrBlank()) req.addRequestHeader("User-Agent", ua)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            val dm = getApplication<Application>().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(req)
            downloads.add(0, DownloadItem(name, url, System.currentTimeMillis()))
            prefs.saveDownloads(downloads)
            toast(
                if (vpnState == VpnState.On) "Downloading $name (downloads use your normal connection, not the VPN)"
                else "Downloading $name"
            )
        } catch (e: Exception) {
            toast("Download failed")
        }
    }

    // =====================================================================
    //  WebViewClient / WebChromeClient
    // =====================================================================

    private inner class FluxClient(val tab: BrowserTab) : WebViewClient() {

        override fun shouldInterceptRequest(
            view: WebView?,
            request: WebResourceRequest?
        ): WebResourceResponse? {
            if (request == null || request.isForMainFrame) return null
            val host = request.url?.host ?: return null
            val kind = AdBlocker.classify(host)
            if ((kind == 1 && adBlock) || (kind == 2 && trackerBlock)) {
                main.post { onBlocked(tab, kind) }
                return WebResourceResponse(
                    "text/plain", "UTF-8", 204, "No Content", emptyMap(),
                    ByteArrayInputStream(ByteArray(0))
                )
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val u = request?.url ?: return false
            val scheme = u.scheme ?: return false
            if (scheme == "http" || scheme == "https" || scheme == "about" ||
                scheme == "data" || scheme == "blob" || scheme == "javascript"
            ) return false
            try {
                val app = getApplication<Application>()
                if (scheme == "intent") {
                    val i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                    i.addCategory(Intent.CATEGORY_BROWSABLE)
                    i.component = null
                    i.selector = null
                    app.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else {
                    app.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            } catch (_: Exception) {
            }
            return true
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            tab.url = url ?: tab.url
            tab.blocked = 0
            tab.progress = 0.05f
        }

        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
            if (url != null) tab.url = url
            tab.canBack = view?.canGoBack() ?: false
            tab.canForward = view?.canGoForward() ?: false
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            tab.progress = 1f
            if (url != null) tab.url = url
            tab.title = view?.title?.takeIf { it.isNotBlank() } ?: tab.url
            tab.canBack = view?.canGoBack() ?: false
            tab.canForward = view?.canGoForward() ?: false
            if (cosmetic && adBlock) view?.evaluateJavascript(AdBlocker.COSMETIC_JS, null)
            if (!tab.incognito) {
                recordHistory(tab.title, tab.url)
                saveTabs()
            }
            prefs.totalAds = totalAds
            prefs.totalTrackers = totalTrackers
        }

        override fun onReceivedHttpAuthRequest(
            view: WebView?, handler: HttpAuthHandler?, host: String?, realm: String?
        ) {
            val s = activeServer
            if (handler != null && s != null && vpnState == VpnState.On && host == s.host && s.user.isNotEmpty()) {
                handler.proceed(s.user, s.pass)
            } else {
                handler?.cancel()
            }
        }
    }

    private inner class FluxChrome(val tab: BrowserTab) : WebChromeClient() {

        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            tab.progress = newProgress / 100f
        }

        override fun onReceivedTitle(view: WebView?, title: String?) {
            if (!title.isNullOrBlank()) tab.title = title
        }

        override fun onCreateWindow(
            view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
        ): Boolean {
            if (resultMsg == null) return false
            if (popupBlock && !isUserGesture) {
                main.post { tab.blocked++ }
                return false
            }
            val t = newTabInternal(tab.incognito)
            val wv = ensureWebView(t)
            val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
            transport.webView = wv
            resultMsg.sendToTarget()
            currentId = t.id
            return true
        }

        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            val launcher = launchFileChooser ?: return false
            if (filePathCallback == null || fileChooserParams == null) return false
            fileCallback?.onReceiveValue(null)
            fileCallback = filePathCallback
            return try {
                launcher(fileChooserParams.createIntent())
                true
            } catch (e: Exception) {
                fileCallback = null
                false
            }
        }

        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
            if (view == null) return
            customCb = callback
            fullscreenView = view
        }

        override fun onHideCustomView() {
            exitFullscreen()
        }
    }
}
