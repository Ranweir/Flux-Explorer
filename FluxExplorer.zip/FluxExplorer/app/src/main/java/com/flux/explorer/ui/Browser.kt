package com.flux.explorer.ui

import android.content.Intent
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.flux.explorer.BrowserTab
import com.flux.explorer.BrowserViewModel
import com.flux.explorer.Overlay
import com.flux.explorer.VpnState

// =====================================================================
//  Browser screen: URL bar on top, page in the middle, toolbar at the bottom
// =====================================================================

@Composable
fun BrowserScreen(vm: BrowserViewModel) {
    val tab = vm.current ?: return
    val p = P
    val ctx = LocalContext.current
    var editing by remember(tab.id) { mutableStateOf(false) }
    var text by remember(tab.id) { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val vpnOn = vm.vpnState == VpnState.On

    LaunchedEffect(editing) {
        if (editing) {
            try {
                focus.requestFocus()
            } catch (_: Exception) {
            }
        }
    }

    Column(Modifier.fillMaxSize().background(p.bg)) {
        // ---- top bar ----
        Row(
            Modifier
                .fillMaxWidth()
                .background(p.card)
                .statusBarsPadding()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // shield badge with blocked count on this page
            Row(
                Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.sky)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Filled.Shield, "Blocked on this page",
                    tint = if (vm.adBlock || vm.trackerBlock) p.accent else p.muted,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(tab.blocked.toString(), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.width(8.dp))

            // URL pill
            Row(
                Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(21.dp))
                    .background(p.bg)
                    .clickable(enabled = !editing) {
                        text = tab.url
                        editing = true
                    }
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (editing) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        singleLine = true,
                        textStyle = TextStyle(color = p.text, fontSize = 14.sp),
                        cursorBrush = SolidColor(p.accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                        keyboardActions = KeyboardActions(onGo = {
                            editing = false
                            vm.go(text)
                        }),
                        modifier = Modifier.weight(1f).focusRequester(focus)
                    )
                    Icon(
                        Icons.Outlined.Close, "Cancel", tint = p.muted,
                        modifier = Modifier.size(18.dp).clickable { editing = false }
                    )
                } else {
                    if (tab.incognito) {
                        Icon(Icons.Outlined.VisibilityOff, null, tint = p.muted, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                    } else if (tab.url.startsWith("https://")) {
                        Icon(Icons.Outlined.Lock, null, tint = p.good, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        tab.host.ifBlank { "Search or type a URL" },
                        color = p.text, fontSize = 14.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    if (vpnOn) {
                        Text("VPN", color = p.good, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.width(4.dp))
            Icon(
                Icons.Outlined.Refresh, "Reload", tint = p.text,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable { tab.webView?.reload() }
                    .padding(9.dp)
            )
        }

        if (tab.progress in 0.01f..0.99f) {
            LinearProgressIndicator(
                progress = { tab.progress },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = p.accent,
                trackColor = Color.Transparent
            )
        } else {
            Spacer(Modifier.height(2.dp))
        }

        // ---- page ----
        Box(Modifier.weight(1f).fillMaxWidth()) {
            WebHost(vm, tab)
        }

        // ---- bottom toolbar ----
        Row(
            Modifier
                .fillMaxWidth()
                .background(p.card)
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolIcon(Icons.Filled.ArrowBack, "Back", true) {
                val wv = tab.webView
                if (wv != null && wv.canGoBack()) wv.goBack() else vm.browserOpen = false
            }
            ToolIcon(Icons.Filled.ArrowForward, "Forward", tab.canForward) { tab.webView?.goForward() }
            ToolIcon(Icons.Outlined.Home, "Home", true) {
                vm.browserOpen = false
                vm.mainTab = MainTab.Home
            }
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(2.dp, p.text, RoundedCornerShape(12.dp))
                    .clickable { vm.overlay = Overlay.Tabs },
                contentAlignment = Alignment.Center
            ) {
                Text(vm.tabs.size.toString(), color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Box {
                ToolIcon(Icons.Outlined.MoreVert, "Menu", true) { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    val bookmarked = vm.isBookmarked(tab.url)
                    MenuItem("New tab") { menu = false; vm.newTab(false) }
                    MenuItem("New private tab") { menu = false; vm.newTab(true) }
                    MenuItem(if (bookmarked) "Remove bookmark" else "Add bookmark") {
                        menu = false
                        vm.toggleBookmark(tab)
                    }
                    MenuItem(if (tab.desktop) "✓  Desktop site" else "Desktop site") {
                        menu = false
                        vm.setDesktop(tab, !tab.desktop)
                    }
                    MenuItem("Share") {
                        menu = false
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, tab.url)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Share link"))
                    }
                    MenuItem("Bookmarks") { menu = false; vm.overlay = Overlay.Bookmarks }
                    MenuItem("History") { menu = false; vm.overlay = Overlay.History }
                    MenuItem("Downloads") { menu = false; vm.overlay = Overlay.Downloads }
                }
            }
        }
    }
}

@Composable
private fun MenuItem(label: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(label) }, onClick = onClick)
}

@Composable
private fun ToolIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val p = P
    Icon(
        icon, desc,
        tint = if (enabled) p.text else p.muted.copy(alpha = 0.4f),
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled) { onClick() }
            .padding(10.dp)
    )
}

@Composable
private fun WebHost(vm: BrowserViewModel, tab: BrowserTab) {
    val ctx = LocalContext.current
    androidx.compose.runtime.key(tab.id) {
        AndroidView(
            factory = { vm.attach(ctx, tab) },
            modifier = Modifier.fillMaxSize(),
            onRelease = { view: WebView -> vm.detach(view) }
        )
    }
}

// =====================================================================
//  Overlays: tabs, bookmarks, history, downloads
// =====================================================================

@Composable
fun OverlayScreen(vm: BrowserViewModel) {
    val p = P
    val title = when (vm.overlay) {
        Overlay.Tabs -> "Tabs"
        Overlay.Bookmarks -> "Bookmarks"
        Overlay.History -> "History"
        Overlay.Downloads -> "Downloads"
        Overlay.None -> ""
    }
    Column(Modifier.fillMaxSize().background(p.bg)) {
        // navy header
        Row(
            Modifier
                .fillMaxWidth()
                .background(p.navy)
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIcon(Icons.Filled.ArrowBack, { vm.overlay = Overlay.None }, size = 42.dp, bg = p.navy2, tint = Color.White)
            Spacer(Modifier.width(14.dp))
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            when (vm.overlay) {
                Overlay.History -> CircleIcon(Icons.Outlined.Delete, { vm.clearHistory() }, size = 42.dp, bg = p.navy2, tint = Color.White)
                Overlay.Downloads -> CircleIcon(Icons.Outlined.Delete, { vm.clearDownloads() }, size = 42.dp, bg = p.navy2, tint = Color.White)
                else -> {}
            }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(p.bg)
        ) {
            when (vm.overlay) {
                Overlay.Tabs -> TabsGrid(vm)
                Overlay.Bookmarks -> SiteList(
                    vm, vm.bookmarks, "No bookmarks yet.\nUse the ⋮ menu in a page to add one.",
                    Icons.Outlined.Bookmark
                ) { vm.removeBookmark(it) }
                Overlay.History -> SiteList(
                    vm, vm.history, "Nothing here yet.", Icons.Outlined.History
                ) { vm.removeHistory(it) }
                Overlay.Downloads -> DownloadsList(vm)
                Overlay.None -> {}
            }
        }
    }
}

@Composable
private fun TabsGrid(vm: BrowserViewModel) {
    val p = P
    Column(Modifier.fillMaxSize()) {
        if (vm.tabs.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No open tabs", color = p.muted, fontSize = 14.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(vm.tabs.toList(), key = { it.id }) { t ->
                    val active = t.id == vm.currentId
                    Column(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(p.card)
                            .border(2.dp, if (active) p.accent else Color.Transparent, RoundedCornerShape(20.dp))
                            .clickable { vm.switchTab(t.id) }
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(30.dp).clip(CircleShape).background(if (t.incognito) p.navy else p.sky),
                                contentAlignment = Alignment.Center
                            ) {
                                if (t.incognito) {
                                    Icon(Icons.Outlined.VisibilityOff, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                } else {
                                    Text(
                                        (t.host.ifBlank { "N" }).take(1).uppercase(),
                                        color = p.accent, fontWeight = FontWeight.Bold, fontSize = 13.sp
                                    )
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            Icon(
                                Icons.Outlined.Close, "Close tab", tint = p.muted,
                                modifier = Modifier.size(22.dp).clickable { vm.closeTab(t.id) }
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            if (t.url.isBlank()) "New tab" else t.title,
                            color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            if (t.incognito) "Private" else t.host,
                            color = p.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                Modifier
                    .weight(1f)
                    .height(54.dp)
                    .clip(RoundedCornerShape(27.dp))
                    .background(navyBrush())
                    .clickable { vm.newTab(false) },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Outlined.Add, null, tint = Color.White, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("New tab", color = Color.White, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            }
            Row(
                Modifier
                    .weight(1f)
                    .height(54.dp)
                    .clip(RoundedCornerShape(27.dp))
                    .background(p.sky)
                    .clickable { vm.newTab(true) },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Outlined.VisibilityOff, null, tint = p.accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("Private tab", color = p.accent, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun SiteList(
    vm: BrowserViewModel,
    sites: List<com.flux.explorer.Site>,
    emptyText: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onRemove: (com.flux.explorer.Site) -> Unit
) {
    val p = P
    if (sites.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(emptyText, color = p.muted, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(sites.toList()) { s ->
            FxCard(Modifier.clickable { vm.go(s.url) }, radius = 18.dp) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(p.sky),
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, null, tint = p.accent, modifier = Modifier.size(18.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            s.title, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(s.url, color = p.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Icon(
                        Icons.Outlined.Close, "Remove", tint = p.muted,
                        modifier = Modifier.size(20.dp).clickable { onRemove(s) }
                    )
                }
            }
        }
    }
}

@Composable
private fun DownloadsList(vm: BrowserViewModel) {
    val p = P
    val ctx = LocalContext.current
    if (vm.downloads.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No downloads yet.", color = p.muted, fontSize = 14.sp)
        }
        return
    }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vm.downloads.toList()) { d ->
                FxCard(radius = 18.dp) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(38.dp).clip(CircleShape).background(p.sky),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Outlined.Download, null, tint = p.accent, modifier = Modifier.size(18.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                d.name, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(d.url, color = p.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(16.dp)
                .height(54.dp)
                .clip(RoundedCornerShape(27.dp))
                .background(p.sky)
                .clickable {
                    try {
                        ctx.startActivity(
                            Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Text("Open Downloads folder", color = p.accent, fontWeight = FontWeight.Medium, fontSize = 14.sp)
        }
    }
}
