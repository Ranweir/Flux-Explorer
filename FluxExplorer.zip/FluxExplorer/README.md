# Flux Explorer

A fast Android browser with a built-in ad blocker and a built-in browser VPN, designed with a navy / light-blue card UI.

## Features
- **Ad & tracker blocker**: host-based blocking (ad networks, analytics, trackers), hides empty ad boxes, blocks pop-ups. Optional "Update filter lists" pulls a larger host list.
- **Flux VPN**: routes all browser traffic through an HTTP/HTTPS proxy server you add. Same idea as Opera's browser VPN: it protects this browser only, not other apps. No direct fallback, so your real IP is never used if the proxy fails.
- **Chrome extensions** (no desktop mode): install from the Chrome Web Store link/ID or a .crx/.zip file. Runs the page-changing (content script) part of extensions; background pages and popups are not supported.
- Tabs, private tabs (no history, no cache), bookmarks, history, downloads
- Desktop site mode, share, fullscreen video, file upload, default-browser support
- Search engines: Google (default), DuckDuckGo, Bing, Brave
- Light and dark themes (follows the system)

## VPN setup
No server? Tap **Connect** (or **Find free** in the Servers list): the app downloads public proxy lists, tests each one on your phone with a real HTTPS request, and adds the fastest working ones. Free public proxies are shared and slow; avoid banking and important logins on them.

Flux VPN needs a proxy server (your own, or from a proxy provider). Open the **VPN** tab, tap **Add**, enter host, port and HTTP/HTTPS (and username/password if the proxy needs them), then tap **Connect**. Use **Check my IP** to confirm the IP changed.

## Build
- **GitHub Actions**: push this repo to GitHub. The workflow in `.github/workflows/build.yml` builds the APK; download it from the run's *Artifacts*.
- **Android Studio**: open the folder, let it sync, then run `app`.

Requires JDK 17, minSdk 26 (Android 8.0+).

## Notes
- Android WebView shares one cookie jar, so private tabs don't save history or cache but can't hide cookies from normal tabs.
- Proxy credentials are stored in the app's private storage.
- Downloads use Android's download manager, which doesn't go through the VPN proxy.
